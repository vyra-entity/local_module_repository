// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:msg/VBASEErrorFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_error_feed.h"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_H_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'uuid'
// Member 'description'
// Member 'solution'
// Member 'miscellaneous'
// Member 'module_name'
#include "rosidl_runtime_c/string.h"
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'module_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in msg/VBASEErrorFeed in the package vyra_module_interfaces.
/**
  * ErrorFeed.msg
 */
typedef struct vyra_module_interfaces__msg__VBASEErrorFeed
{
  uint8_t level;
  uint32_t code;
  rosidl_runtime_c__String uuid;
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String description;
  rosidl_runtime_c__String solution;
  rosidl_runtime_c__String miscellaneous;
  rosidl_runtime_c__String module_name;
  unique_identifier_msgs__msg__UUID module_id;
} vyra_module_interfaces__msg__VBASEErrorFeed;

// Struct for a sequence of vyra_module_interfaces__msg__VBASEErrorFeed.
typedef struct vyra_module_interfaces__msg__VBASEErrorFeed__Sequence
{
  vyra_module_interfaces__msg__VBASEErrorFeed * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__msg__VBASEErrorFeed__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_H_
