// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__VBASE_GET_INTERFACE_LIST_HPP_
#define VYRA_MODULE_INTERFACES__SRV__VBASE_GET_INTERFACE_LIST_HPP_

#include "vyra_module_interfaces/srv/detail/vbase_get_interface_list__struct.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_get_interface_list__builder.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_get_interface_list__traits.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_get_interface_list__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__SRV__VBASE_GET_INTERFACE_LIST_HPP_
