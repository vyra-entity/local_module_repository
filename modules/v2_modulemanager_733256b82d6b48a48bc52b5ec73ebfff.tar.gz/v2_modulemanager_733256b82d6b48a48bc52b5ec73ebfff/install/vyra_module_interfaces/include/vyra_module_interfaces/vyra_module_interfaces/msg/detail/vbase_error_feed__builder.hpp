// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASEErrorFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_error_feed.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_error_feed__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASEErrorFeed_module_id
{
public:
  explicit Init_VBASEErrorFeed_module_id(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::msg::VBASEErrorFeed module_id(::vyra_module_interfaces::msg::VBASEErrorFeed::_module_id_type arg)
  {
    msg_.module_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_module_name
{
public:
  explicit Init_VBASEErrorFeed_module_name(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_module_id module_name(::vyra_module_interfaces::msg::VBASEErrorFeed::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_VBASEErrorFeed_module_id(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_miscellaneous
{
public:
  explicit Init_VBASEErrorFeed_miscellaneous(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_module_name miscellaneous(::vyra_module_interfaces::msg::VBASEErrorFeed::_miscellaneous_type arg)
  {
    msg_.miscellaneous = std::move(arg);
    return Init_VBASEErrorFeed_module_name(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_solution
{
public:
  explicit Init_VBASEErrorFeed_solution(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_miscellaneous solution(::vyra_module_interfaces::msg::VBASEErrorFeed::_solution_type arg)
  {
    msg_.solution = std::move(arg);
    return Init_VBASEErrorFeed_miscellaneous(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_description
{
public:
  explicit Init_VBASEErrorFeed_description(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_solution description(::vyra_module_interfaces::msg::VBASEErrorFeed::_description_type arg)
  {
    msg_.description = std::move(arg);
    return Init_VBASEErrorFeed_solution(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_timestamp
{
public:
  explicit Init_VBASEErrorFeed_timestamp(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_description timestamp(::vyra_module_interfaces::msg::VBASEErrorFeed::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_VBASEErrorFeed_description(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_uuid
{
public:
  explicit Init_VBASEErrorFeed_uuid(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_timestamp uuid(::vyra_module_interfaces::msg::VBASEErrorFeed::_uuid_type arg)
  {
    msg_.uuid = std::move(arg);
    return Init_VBASEErrorFeed_timestamp(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_code
{
public:
  explicit Init_VBASEErrorFeed_code(::vyra_module_interfaces::msg::VBASEErrorFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEErrorFeed_uuid code(::vyra_module_interfaces::msg::VBASEErrorFeed::_code_type arg)
  {
    msg_.code = std::move(arg);
    return Init_VBASEErrorFeed_uuid(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

class Init_VBASEErrorFeed_level
{
public:
  Init_VBASEErrorFeed_level()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEErrorFeed_code level(::vyra_module_interfaces::msg::VBASEErrorFeed::_level_type arg)
  {
    msg_.level = std::move(arg);
    return Init_VBASEErrorFeed_code(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEErrorFeed msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASEErrorFeed>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASEErrorFeed_level();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__BUILDER_HPP_
