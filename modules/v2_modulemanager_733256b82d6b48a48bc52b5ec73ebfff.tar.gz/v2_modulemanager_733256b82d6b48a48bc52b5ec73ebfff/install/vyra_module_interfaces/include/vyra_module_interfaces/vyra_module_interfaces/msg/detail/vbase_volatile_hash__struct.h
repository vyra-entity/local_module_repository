// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:msg/VBASEVolatileHash.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_volatile_hash.h"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__STRUCT_H_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'entries'
#include "vyra_module_interfaces/msg/detail/vbase_key_value__struct.h"

/// Struct defined in msg/VBASEVolatileHash in the package vyra_module_interfaces.
/**
  * VolatileHash.msg
 */
typedef struct vyra_module_interfaces__msg__VBASEVolatileHash
{
  vyra_module_interfaces__msg__VBASEKeyValue__Sequence entries;
} vyra_module_interfaces__msg__VBASEVolatileHash;

// Struct for a sequence of vyra_module_interfaces__msg__VBASEVolatileHash.
typedef struct vyra_module_interfaces__msg__VBASEVolatileHash__Sequence
{
  vyra_module_interfaces__msg__VBASEVolatileHash * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__msg__VBASEVolatileHash__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__STRUCT_H_
