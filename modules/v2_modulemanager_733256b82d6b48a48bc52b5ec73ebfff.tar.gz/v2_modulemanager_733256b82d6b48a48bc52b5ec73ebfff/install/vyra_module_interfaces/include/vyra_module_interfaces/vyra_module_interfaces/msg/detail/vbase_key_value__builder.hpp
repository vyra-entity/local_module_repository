// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASEKeyValue.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_key_value.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_KEY_VALUE__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_KEY_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_key_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASEKeyValue_value
{
public:
  explicit Init_VBASEKeyValue_value(::vyra_module_interfaces::msg::VBASEKeyValue & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::msg::VBASEKeyValue value(::vyra_module_interfaces::msg::VBASEKeyValue::_value_type arg)
  {
    msg_.value = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEKeyValue msg_;
};

class Init_VBASEKeyValue_key
{
public:
  Init_VBASEKeyValue_key()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEKeyValue_value key(::vyra_module_interfaces::msg::VBASEKeyValue::_key_type arg)
  {
    msg_.key = std::move(arg);
    return Init_VBASEKeyValue_value(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEKeyValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASEKeyValue>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASEKeyValue_key();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_KEY_VALUE__BUILDER_HPP_
