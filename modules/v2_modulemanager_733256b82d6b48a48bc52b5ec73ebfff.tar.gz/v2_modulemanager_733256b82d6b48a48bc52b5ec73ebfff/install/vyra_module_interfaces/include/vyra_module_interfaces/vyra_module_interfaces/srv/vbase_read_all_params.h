// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:srv/VBASEReadAllParams.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__VBASE_READ_ALL_PARAMS_H_
#define VYRA_MODULE_INTERFACES__SRV__VBASE_READ_ALL_PARAMS_H_

#include "vyra_module_interfaces/srv/detail/vbase_read_all_params__struct.h"
#include "vyra_module_interfaces/srv/detail/vbase_read_all_params__functions.h"
#include "vyra_module_interfaces/srv/detail/vbase_read_all_params__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__SRV__VBASE_READ_ALL_PARAMS_H_
