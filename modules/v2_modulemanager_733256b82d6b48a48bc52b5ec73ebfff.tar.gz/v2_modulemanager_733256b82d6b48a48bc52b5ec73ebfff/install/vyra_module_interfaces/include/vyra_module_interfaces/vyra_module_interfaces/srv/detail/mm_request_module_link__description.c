// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:srv/MMRequestModuleLink.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/srv/detail/mm_request_module_link__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRequestModuleLink__get_type_hash(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x36, 0x3d, 0x09, 0x43, 0xf5, 0x18, 0x76, 0x69,
      0x6d, 0x83, 0xcd, 0x27, 0x29, 0x54, 0xa3, 0xf3,
      0x22, 0xf5, 0x7a, 0x6f, 0x94, 0xa9, 0xf6, 0x1b,
      0x3a, 0x65, 0xd2, 0x95, 0x93, 0x21, 0xf0, 0x6c,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x4c, 0xad, 0x03, 0xfc, 0xdc, 0xb2, 0xb5, 0x8f,
      0xe9, 0x17, 0x47, 0xad, 0x3e, 0x18, 0xe7, 0xcb,
      0x98, 0x03, 0x34, 0xb6, 0x8e, 0x09, 0xde, 0x05,
      0x00, 0x14, 0xef, 0x6d, 0x6a, 0xaa, 0xbc, 0xeb,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x9c, 0x69, 0xeb, 0x9e, 0xdc, 0xf4, 0x94, 0x6b,
      0x0f, 0xb2, 0x2b, 0xb5, 0xc6, 0x15, 0x27, 0x67,
      0x65, 0xb9, 0x9b, 0x9d, 0xa8, 0x7d, 0xee, 0x00,
      0x25, 0x91, 0x14, 0x59, 0xac, 0x4b, 0x0a, 0xf5,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x80, 0x8c, 0xc7, 0x74, 0xc1, 0xb7, 0xd8, 0x0b,
      0xf5, 0x46, 0xd3, 0xcd, 0xcb, 0x0b, 0x9f, 0xd0,
      0x26, 0x50, 0xcd, 0x8e, 0x06, 0xfc, 0x88, 0xa0,
      0xc4, 0xaf, 0xa5, 0x88, 0xca, 0x15, 0x3d, 0xa8,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "service_msgs/msg/detail/service_event_info__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t service_msgs__msg__ServiceEventInfo__EXPECTED_HASH = {1, {
    0x41, 0xbc, 0xbb, 0xe0, 0x7a, 0x75, 0xc9, 0xb5,
    0x2b, 0xc9, 0x6b, 0xfd, 0x5c, 0x24, 0xd7, 0xf0,
    0xfc, 0x0a, 0x08, 0xc0, 0xcb, 0x79, 0x21, 0xb3,
    0x37, 0x3c, 0x57, 0x32, 0x34, 0x5a, 0x6f, 0x45,
  }};
#endif

static char vyra_module_interfaces__srv__MMRequestModuleLink__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRequestModuleLink";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char service_msgs__msg__ServiceEventInfo__TYPE_NAME[] = "service_msgs/msg/ServiceEventInfo";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Event__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRequestModuleLink_Event";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRequestModuleLink_Request";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRequestModuleLink_Response";

// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__request_message[] = "request_message";
static char vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__response_message[] = "response_message";
static char vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__event_message[] = "event_message";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRequestModuleLink__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__request_message, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__response_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink__FIELD_NAME__event_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRequestModuleLink_Event__TYPE_NAME, 52, 52},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__srv__MMRequestModuleLink__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__TYPE_NAME, 52, 52},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRequestModuleLink__get_type_description(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRequestModuleLink__TYPE_NAME, 46, 46},
      {vyra_module_interfaces__srv__MMRequestModuleLink__FIELDS, 3, 3},
    },
    {vyra_module_interfaces__srv__MMRequestModuleLink__REFERENCED_TYPE_DESCRIPTIONS, 5, 5},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__module_id[] = "module_id";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__module_name[] = "module_name";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__function_scope[] = "function_scope";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__username[] = "username";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__password[] = "password";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__module_id, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__module_name, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__function_scope, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__username, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELD_NAME__password, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
      {vyra_module_interfaces__srv__MMRequestModuleLink_Request__FIELDS, 5, 5},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__link_status[] = "link_status";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__error_message[] = "error_message";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__signed_permission_file[] = "signed_permission_file";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__link_status, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__error_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELD_NAME__signed_permission_file, 22, 22},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
      {vyra_module_interfaces__srv__MMRequestModuleLink_Response__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__info[] = "info";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__request[] = "request";
static char vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__response[] = "response";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__info, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__request, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELD_NAME__response, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__srv__MMRequestModuleLink_Event__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRequestModuleLink_Event__TYPE_NAME, 52, 52},
      {vyra_module_interfaces__srv__MMRequestModuleLink_Event__FIELDS, 3, 3},
    },
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__REFERENCED_TYPE_DESCRIPTIONS, 4, 4},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[2].fields = vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# MMRequestModuleLink.srv\n"
  "# Request\n"
  "string module_id\n"
  "string module_name\n"
  "string function_scope\n"
  "string username\n"
  "string password\n"
  "\n"
  "---\n"
  "# Response\n"
  "int8 link_status\n"
  "string error_message\n"
  "string signed_permission_file\n"
  "\n"
  "# RequestModuleLink:\n"
  "# A request to be called from a module to allow access to its resources defined in function_scope.\n"
  "# The module to be requested will be called to allow the request. If the request will be\n"
  "# granted the link will be added to the database and to the permission file of the requesting\n"
  "# module, signed and sent back\n"
  "\n"
  "# Link status:\n"
  "# GRANTED = 0\n"
  "# NOT_ALLOWED = 1\n"
  "# VULNERABLE_DETECTED = 2\n"
  "# BLOCKED = 3\n"
  "# INTERNAL_ERROR = 4";

static char srv_encoding[] = "srv";
static char implicit_encoding[] = "implicit";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRequestModuleLink__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRequestModuleLink__TYPE_NAME, 46, 46},
    {srv_encoding, 3, 3},
    {toplevel_type_raw_source, 654, 654},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Request__TYPE_NAME, 54, 54},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Response__TYPE_NAME, 55, 55},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRequestModuleLink_Event__TYPE_NAME, 52, 52},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRequestModuleLink__get_type_description_sources(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[6];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 6, 6};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRequestModuleLink__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_individual_type_description_source(NULL);
    sources[4] = *vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_individual_type_description_source(NULL);
    sources[5] = *vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[5];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 5, 5};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRequestModuleLink_Event__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *vyra_module_interfaces__srv__MMRequestModuleLink_Request__get_individual_type_description_source(NULL);
    sources[4] = *vyra_module_interfaces__srv__MMRequestModuleLink_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
