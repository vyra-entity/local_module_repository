Template framework for building new python vyra modules
