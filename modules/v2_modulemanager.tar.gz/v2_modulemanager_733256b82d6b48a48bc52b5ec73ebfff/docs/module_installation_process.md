 ### Module installation process

 - A module docker container will be installed on the corresponding hardware
 - The 