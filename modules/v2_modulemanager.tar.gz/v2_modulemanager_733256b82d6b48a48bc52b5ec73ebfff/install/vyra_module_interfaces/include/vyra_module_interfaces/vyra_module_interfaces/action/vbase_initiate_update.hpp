// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_HPP_
#define VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_HPP_

#include "vyra_module_interfaces/action/detail/vbase_initiate_update__struct.hpp"
#include "vyra_module_interfaces/action/detail/vbase_initiate_update__builder.hpp"
#include "vyra_module_interfaces/action/detail/vbase_initiate_update__traits.hpp"
#include "vyra_module_interfaces/action/detail/vbase_initiate_update__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_HPP_
