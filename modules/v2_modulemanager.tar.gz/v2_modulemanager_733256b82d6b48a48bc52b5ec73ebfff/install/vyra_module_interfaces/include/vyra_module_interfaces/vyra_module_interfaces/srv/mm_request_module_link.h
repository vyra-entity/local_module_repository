// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:srv/MMRequestModuleLink.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__MM_REQUEST_MODULE_LINK_H_
#define VYRA_MODULE_INTERFACES__SRV__MM_REQUEST_MODULE_LINK_H_

#include "vyra_module_interfaces/srv/detail/mm_request_module_link__struct.h"
#include "vyra_module_interfaces/srv/detail/mm_request_module_link__functions.h"
#include "vyra_module_interfaces/srv/detail/mm_request_module_link__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__SRV__MM_REQUEST_MODULE_LINK_H_
