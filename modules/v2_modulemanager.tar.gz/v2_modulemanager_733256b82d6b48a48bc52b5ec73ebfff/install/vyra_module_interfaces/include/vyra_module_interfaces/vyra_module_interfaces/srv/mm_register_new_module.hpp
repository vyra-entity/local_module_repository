// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__MM_REGISTER_NEW_MODULE_HPP_
#define VYRA_MODULE_INTERFACES__SRV__MM_REGISTER_NEW_MODULE_HPP_

#include "vyra_module_interfaces/srv/detail/mm_register_new_module__struct.hpp"
#include "vyra_module_interfaces/srv/detail/mm_register_new_module__builder.hpp"
#include "vyra_module_interfaces/srv/detail/mm_register_new_module__traits.hpp"
#include "vyra_module_interfaces/srv/detail/mm_register_new_module__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__SRV__MM_REGISTER_NEW_MODULE_HPP_
