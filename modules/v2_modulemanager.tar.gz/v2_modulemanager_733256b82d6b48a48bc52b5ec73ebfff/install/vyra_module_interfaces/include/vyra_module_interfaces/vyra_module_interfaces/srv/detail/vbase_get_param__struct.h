// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:srv/VBASEGetParam.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/vbase_get_param.h"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_PARAM__STRUCT_H_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_PARAM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'key'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/VBASEGetParam in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Request
{
  /// Request
  rosidl_runtime_c__String key;
} vyra_module_interfaces__srv__VBASEGetParam_Request;

// Struct for a sequence of vyra_module_interfaces__srv__VBASEGetParam_Request.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Request__Sequence
{
  vyra_module_interfaces__srv__VBASEGetParam_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__VBASEGetParam_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'error_message'
// Member 'json_value'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/VBASEGetParam in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Response
{
  bool success;
  rosidl_runtime_c__String error_message;
  rosidl_runtime_c__String json_value;
} vyra_module_interfaces__srv__VBASEGetParam_Response;

// Struct for a sequence of vyra_module_interfaces__srv__VBASEGetParam_Response.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Response__Sequence
{
  vyra_module_interfaces__srv__VBASEGetParam_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__VBASEGetParam_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  vyra_module_interfaces__srv__VBASEGetParam_Event__request__MAX_SIZE = 1
};
// response
enum
{
  vyra_module_interfaces__srv__VBASEGetParam_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/VBASEGetParam in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Event
{
  service_msgs__msg__ServiceEventInfo info;
  vyra_module_interfaces__srv__VBASEGetParam_Request__Sequence request;
  vyra_module_interfaces__srv__VBASEGetParam_Response__Sequence response;
} vyra_module_interfaces__srv__VBASEGetParam_Event;

// Struct for a sequence of vyra_module_interfaces__srv__VBASEGetParam_Event.
typedef struct vyra_module_interfaces__srv__VBASEGetParam_Event__Sequence
{
  vyra_module_interfaces__srv__VBASEGetParam_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__VBASEGetParam_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_PARAM__STRUCT_H_
