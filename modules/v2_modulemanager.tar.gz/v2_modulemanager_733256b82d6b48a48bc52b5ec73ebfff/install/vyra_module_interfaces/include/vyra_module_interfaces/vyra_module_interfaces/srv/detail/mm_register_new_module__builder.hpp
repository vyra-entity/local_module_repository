// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:srv/MMRegisterNewModule.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/mm_register_new_module.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/srv/detail/mm_register_new_module__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRegisterNewModule_Request_dependencies
{
public:
  explicit Init_MMRegisterNewModule_Request_dependencies(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request dependencies(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_dependencies_type arg)
  {
    msg_.dependencies = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_license
{
public:
  explicit Init_MMRegisterNewModule_Request_license(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_dependencies license(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_license_type arg)
  {
    msg_.license = std::move(arg);
    return Init_MMRegisterNewModule_Request_dependencies(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_interfaces
{
public:
  explicit Init_MMRegisterNewModule_Request_interfaces(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_license interfaces(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_interfaces_type arg)
  {
    msg_.interfaces = std::move(arg);
    return Init_MMRegisterNewModule_Request_license(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_function_scope
{
public:
  explicit Init_MMRegisterNewModule_Request_function_scope(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_interfaces function_scope(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_function_scope_type arg)
  {
    msg_.function_scope = std::move(arg);
    return Init_MMRegisterNewModule_Request_interfaces(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_version
{
public:
  explicit Init_MMRegisterNewModule_Request_version(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_function_scope version(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_version_type arg)
  {
    msg_.version = std::move(arg);
    return Init_MMRegisterNewModule_Request_function_scope(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_author
{
public:
  explicit Init_MMRegisterNewModule_Request_author(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_version author(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_author_type arg)
  {
    msg_.author = std::move(arg);
    return Init_MMRegisterNewModule_Request_version(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_description
{
public:
  explicit Init_MMRegisterNewModule_Request_description(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_author description(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_description_type arg)
  {
    msg_.description = std::move(arg);
    return Init_MMRegisterNewModule_Request_author(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_module_name
{
public:
  explicit Init_MMRegisterNewModule_Request_module_name(::vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Request_description module_name(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_MMRegisterNewModule_Request_description(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

class Init_MMRegisterNewModule_Request_module_id
{
public:
  Init_MMRegisterNewModule_Request_module_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRegisterNewModule_Request_module_name module_id(::vyra_module_interfaces::srv::MMRegisterNewModule_Request::_module_id_type arg)
  {
    msg_.module_id = std::move(arg);
    return Init_MMRegisterNewModule_Request_module_name(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRegisterNewModule_Request>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRegisterNewModule_Request_module_id();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRegisterNewModule_Response_error_message
{
public:
  explicit Init_MMRegisterNewModule_Response_error_message(::vyra_module_interfaces::srv::MMRegisterNewModule_Response & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Response error_message(::vyra_module_interfaces::srv::MMRegisterNewModule_Response::_error_message_type arg)
  {
    msg_.error_message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Response msg_;
};

class Init_MMRegisterNewModule_Response_signed_permissions
{
public:
  explicit Init_MMRegisterNewModule_Response_signed_permissions(::vyra_module_interfaces::srv::MMRegisterNewModule_Response & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Response_error_message signed_permissions(::vyra_module_interfaces::srv::MMRegisterNewModule_Response::_signed_permissions_type arg)
  {
    msg_.signed_permissions = std::move(arg);
    return Init_MMRegisterNewModule_Response_error_message(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Response msg_;
};

class Init_MMRegisterNewModule_Response_register_status
{
public:
  Init_MMRegisterNewModule_Response_register_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRegisterNewModule_Response_signed_permissions register_status(::vyra_module_interfaces::srv::MMRegisterNewModule_Response::_register_status_type arg)
  {
    msg_.register_status = std::move(arg);
    return Init_MMRegisterNewModule_Response_signed_permissions(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRegisterNewModule_Response>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRegisterNewModule_Response_register_status();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRegisterNewModule_Event_response
{
public:
  explicit Init_MMRegisterNewModule_Event_response(::vyra_module_interfaces::srv::MMRegisterNewModule_Event & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Event response(::vyra_module_interfaces::srv::MMRegisterNewModule_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Event msg_;
};

class Init_MMRegisterNewModule_Event_request
{
public:
  explicit Init_MMRegisterNewModule_Event_request(::vyra_module_interfaces::srv::MMRegisterNewModule_Event & msg)
  : msg_(msg)
  {}
  Init_MMRegisterNewModule_Event_response request(::vyra_module_interfaces::srv::MMRegisterNewModule_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MMRegisterNewModule_Event_response(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Event msg_;
};

class Init_MMRegisterNewModule_Event_info
{
public:
  Init_MMRegisterNewModule_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRegisterNewModule_Event_request info(::vyra_module_interfaces::srv::MMRegisterNewModule_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MMRegisterNewModule_Event_request(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRegisterNewModule_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRegisterNewModule_Event>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRegisterNewModule_Event_info();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__BUILDER_HPP_
