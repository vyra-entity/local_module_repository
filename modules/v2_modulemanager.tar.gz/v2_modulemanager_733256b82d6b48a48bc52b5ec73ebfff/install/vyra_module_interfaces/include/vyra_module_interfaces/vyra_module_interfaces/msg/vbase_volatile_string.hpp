// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_STRING_HPP_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_STRING_HPP_

#include "vyra_module_interfaces/msg/detail/vbase_volatile_string__struct.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_volatile_string__builder.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_volatile_string__traits.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_volatile_string__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_STRING_HPP_
