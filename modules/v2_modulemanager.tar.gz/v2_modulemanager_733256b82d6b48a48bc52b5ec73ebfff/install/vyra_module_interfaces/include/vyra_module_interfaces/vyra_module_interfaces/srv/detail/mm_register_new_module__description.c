// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:srv/MMRegisterNewModule.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/srv/detail/mm_register_new_module__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRegisterNewModule__get_type_hash(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x27, 0x77, 0xd8, 0xcd, 0xd6, 0x81, 0x0d, 0x8d,
      0x4c, 0x11, 0x2d, 0x7e, 0x90, 0x16, 0x17, 0xaf,
      0xb1, 0xff, 0x1d, 0x3e, 0x75, 0xba, 0x9b, 0x19,
      0x62, 0xb4, 0x44, 0xc0, 0xb3, 0xbf, 0x06, 0x76,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x03, 0x64, 0xd4, 0xeb, 0xbd, 0x97, 0x91, 0xee,
      0xd9, 0x38, 0xc8, 0x1d, 0x0b, 0x15, 0xa4, 0xb2,
      0x7f, 0xcf, 0xdf, 0x4b, 0x30, 0xb4, 0xad, 0x58,
      0xe9, 0xcb, 0x26, 0x4c, 0xca, 0x15, 0xef, 0x40,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xac, 0x7d, 0x3d, 0x5e, 0x8f, 0xb7, 0xed, 0xf2,
      0xf5, 0x83, 0x6e, 0x6f, 0x61, 0x38, 0x7b, 0x4b,
      0x4b, 0x7a, 0x39, 0x9f, 0x35, 0xbb, 0xcf, 0x77,
      0x3c, 0x61, 0xbf, 0x04, 0xe5, 0xcc, 0x6e, 0xf9,
    }};
  return &hash;
}

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xaa, 0x88, 0x75, 0x5a, 0xd7, 0xf2, 0x88, 0x99,
      0x15, 0x2e, 0x92, 0xc9, 0xca, 0x46, 0x7c, 0x28,
      0xf2, 0x80, 0x28, 0xba, 0x72, 0x01, 0x0a, 0x82,
      0x83, 0x14, 0x5a, 0x79, 0x33, 0x4f, 0x69, 0x47,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "service_msgs/msg/detail/service_event_info__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_key_value__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t service_msgs__msg__ServiceEventInfo__EXPECTED_HASH = {1, {
    0x41, 0xbc, 0xbb, 0xe0, 0x7a, 0x75, 0xc9, 0xb5,
    0x2b, 0xc9, 0x6b, 0xfd, 0x5c, 0x24, 0xd7, 0xf0,
    0xfc, 0x0a, 0x08, 0xc0, 0xcb, 0x79, 0x21, 0xb3,
    0x37, 0x3c, 0x57, 0x32, 0x34, 0x5a, 0x6f, 0x45,
  }};
static const rosidl_type_hash_t vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH = {1, {
    0xf1, 0xb3, 0x1b, 0x9a, 0x16, 0x28, 0x74, 0xc8,
    0x2b, 0xb1, 0x77, 0xce, 0xbe, 0x87, 0x61, 0x15,
    0x89, 0xa3, 0x02, 0x60, 0x27, 0x37, 0xcb, 0x52,
    0x42, 0xaf, 0x11, 0x21, 0x8a, 0x1b, 0x27, 0x87,
  }};
#endif

static char vyra_module_interfaces__srv__MMRegisterNewModule__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRegisterNewModule";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char service_msgs__msg__ServiceEventInfo__TYPE_NAME[] = "service_msgs/msg/ServiceEventInfo";
static char vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEKeyValue";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Event__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRegisterNewModule_Event";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRegisterNewModule_Request";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME[] = "vyra_module_interfaces/srv/MMRegisterNewModule_Response";

// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__request_message[] = "request_message";
static char vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__response_message[] = "response_message";
static char vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__event_message[] = "event_message";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRegisterNewModule__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__request_message, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__response_message, 16, 16},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule__FIELD_NAME__event_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {vyra_module_interfaces__srv__MMRegisterNewModule_Event__TYPE_NAME, 52, 52},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__srv__MMRegisterNewModule__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__TYPE_NAME, 52, 52},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRegisterNewModule__get_type_description(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRegisterNewModule__TYPE_NAME, 46, 46},
      {vyra_module_interfaces__srv__MMRegisterNewModule__FIELDS, 3, 3},
    },
    {vyra_module_interfaces__srv__MMRegisterNewModule__REFERENCED_TYPE_DESCRIPTIONS, 6, 6},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH, vyra_module_interfaces__msg__VBASEKeyValue__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = vyra_module_interfaces__msg__VBASEKeyValue__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[5].fields = vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__module_id[] = "module_id";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__module_name[] = "module_name";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__description[] = "description";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__author[] = "author";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__version[] = "version";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__function_scope[] = "function_scope";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__interfaces[] = "interfaces";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__license[] = "license";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__dependencies[] = "dependencies";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__module_id, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__module_name, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__description, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__author, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__version, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__function_scope, 14, 14},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__interfaces, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__license, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELD_NAME__dependencies, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__srv__MMRegisterNewModule_Request__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
      {vyra_module_interfaces__srv__MMRegisterNewModule_Request__FIELDS, 9, 9},
    },
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH, vyra_module_interfaces__msg__VBASEKeyValue__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = vyra_module_interfaces__msg__VBASEKeyValue__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__register_status[] = "register_status";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__signed_permissions[] = "signed_permissions";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__error_message[] = "error_message";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__register_status, 15, 15},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__signed_permissions, 18, 18},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELD_NAME__error_message, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
      {vyra_module_interfaces__srv__MMRegisterNewModule_Response__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}
// Define type names, field names, and default values
static char vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__info[] = "info";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__request[] = "request";
static char vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__response[] = "response";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELDS[] = {
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__info, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__request, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELD_NAME__response, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_BOUNDED_SEQUENCE,
      1,
      0,
      {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__srv__MMRegisterNewModule_Event__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {service_msgs__msg__ServiceEventInfo__TYPE_NAME, 33, 33},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__srv__MMRegisterNewModule_Event__TYPE_NAME, 52, 52},
      {vyra_module_interfaces__srv__MMRegisterNewModule_Event__FIELDS, 3, 3},
    },
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__REFERENCED_TYPE_DESCRIPTIONS, 5, 5},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&service_msgs__msg__ServiceEventInfo__EXPECTED_HASH, service_msgs__msg__ServiceEventInfo__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = service_msgs__msg__ServiceEventInfo__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH, vyra_module_interfaces__msg__VBASEKeyValue__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[2].fields = vyra_module_interfaces__msg__VBASEKeyValue__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[3].fields = vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_type_description(NULL)->type_description.fields;
    description.referenced_type_descriptions.data[4].fields = vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# MMRegisterNewModule.srv\n"
  "# Request\n"
  "string module_id\n"
  "string module_name\n"
  "string description\n"
  "string author\n"
  "string version\n"
  "string function_scope\n"
  "string interfaces\n"
  "string license\n"
  "VBASEKeyValue[] dependencies\n"
  "\n"
  "---\n"
  "# Response\n"
  "int8 register_status\n"
  "string signed_permissions\n"
  "string error_message\n"
  "\n"
  "# RegisterNewModule:\n"
  "# Receving data to add a module to the database and generate a signed permission token\n"
  "# which allows the module to present their own speaker, callables and jobs in the domain,\n"
  "# this module manager is responsible for\n"
  "\n"
  "# Function scope:\n"
  "# Collection of all speaker, callables and jobs of a module whants to be published\n"
  "\n"
  "# Interface list:\n"
  "# Containing a dictionaries(json-serialized) with the interfaces, used by the function scope the\n"
  "# module provided. For example: {\\'srv/MMRegisterNewModule.srv\\': \"# MMRegisterNewModule.srv\\\\n# Re...\"}\n"
  "\n"
  "# Register status:\n"
  "# SUCCESS = 0\n"
  "# MODULE_ALREADY_EXISTS = 1\n"
  "# INVALID_MODULE_DATA = 2\n"
  "# BUSY = 3\n"
  "# LOCKED = 4\n"
  "# INTERNAL_ERROR = 5\n"
  "\n"
  "# Signed permissions: \n"
  "# Will be transmitted encrypted with the public key of the receiver module";

static char srv_encoding[] = "srv";
static char implicit_encoding[] = "implicit";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRegisterNewModule__get_individual_type_description_source(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRegisterNewModule__TYPE_NAME, 46, 46},
    {srv_encoding, 3, 3},
    {toplevel_type_raw_source, 1079, 1079},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Request__TYPE_NAME, 54, 54},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Response__TYPE_NAME, 55, 55},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__srv__MMRegisterNewModule_Event__TYPE_NAME, 52, 52},
    {implicit_encoding, 8, 8},
    {NULL, 0, 0},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRegisterNewModule__get_type_description_sources(
  const rosidl_service_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[7];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 7, 7};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRegisterNewModule__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *vyra_module_interfaces__msg__VBASEKeyValue__get_individual_type_description_source(NULL);
    sources[4] = *vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_individual_type_description_source(NULL);
    sources[5] = *vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_individual_type_description_source(NULL);
    sources[6] = *vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_individual_type_description_source(NULL),
    sources[1] = *vyra_module_interfaces__msg__VBASEKeyValue__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[6];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 6, 6};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__srv__MMRegisterNewModule_Event__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *service_msgs__msg__ServiceEventInfo__get_individual_type_description_source(NULL);
    sources[3] = *vyra_module_interfaces__msg__VBASEKeyValue__get_individual_type_description_source(NULL);
    sources[4] = *vyra_module_interfaces__srv__MMRegisterNewModule_Request__get_individual_type_description_source(NULL);
    sources[5] = *vyra_module_interfaces__srv__MMRegisterNewModule_Response__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
