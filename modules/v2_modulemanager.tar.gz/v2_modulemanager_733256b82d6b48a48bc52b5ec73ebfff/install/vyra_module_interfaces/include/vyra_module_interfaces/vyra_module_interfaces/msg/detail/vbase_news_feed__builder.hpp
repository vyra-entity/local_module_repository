// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASENewsFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_news_feed.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_news_feed__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASENewsFeed_module_id
{
public:
  explicit Init_VBASENewsFeed_module_id(::vyra_module_interfaces::msg::VBASENewsFeed & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::msg::VBASENewsFeed module_id(::vyra_module_interfaces::msg::VBASENewsFeed::_module_id_type arg)
  {
    msg_.module_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

class Init_VBASENewsFeed_module_name
{
public:
  explicit Init_VBASENewsFeed_module_name(::vyra_module_interfaces::msg::VBASENewsFeed & msg)
  : msg_(msg)
  {}
  Init_VBASENewsFeed_module_id module_name(::vyra_module_interfaces::msg::VBASENewsFeed::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_VBASENewsFeed_module_id(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

class Init_VBASENewsFeed_uuid
{
public:
  explicit Init_VBASENewsFeed_uuid(::vyra_module_interfaces::msg::VBASENewsFeed & msg)
  : msg_(msg)
  {}
  Init_VBASENewsFeed_module_name uuid(::vyra_module_interfaces::msg::VBASENewsFeed::_uuid_type arg)
  {
    msg_.uuid = std::move(arg);
    return Init_VBASENewsFeed_module_name(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

class Init_VBASENewsFeed_timestamp
{
public:
  explicit Init_VBASENewsFeed_timestamp(::vyra_module_interfaces::msg::VBASENewsFeed & msg)
  : msg_(msg)
  {}
  Init_VBASENewsFeed_uuid timestamp(::vyra_module_interfaces::msg::VBASENewsFeed::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_VBASENewsFeed_uuid(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

class Init_VBASENewsFeed_message
{
public:
  explicit Init_VBASENewsFeed_message(::vyra_module_interfaces::msg::VBASENewsFeed & msg)
  : msg_(msg)
  {}
  Init_VBASENewsFeed_timestamp message(::vyra_module_interfaces::msg::VBASENewsFeed::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_VBASENewsFeed_timestamp(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

class Init_VBASENewsFeed_level
{
public:
  Init_VBASENewsFeed_level()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASENewsFeed_message level(::vyra_module_interfaces::msg::VBASENewsFeed::_level_type arg)
  {
    msg_.level = std::move(arg);
    return Init_VBASENewsFeed_message(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASENewsFeed msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASENewsFeed>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASENewsFeed_level();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__BUILDER_HPP_
