// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:srv/MMRegisterNewModule.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/mm_register_new_module.h"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__STRUCT_H_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'module_id'
// Member 'module_name'
// Member 'description'
// Member 'author'
// Member 'version'
// Member 'function_scope'
// Member 'interfaces'
// Member 'license'
#include "rosidl_runtime_c/string.h"
// Member 'dependencies'
#include "vyra_module_interfaces/msg/detail/vbase_key_value__struct.h"

/// Struct defined in srv/MMRegisterNewModule in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Request
{
  rosidl_runtime_c__String module_id;
  rosidl_runtime_c__String module_name;
  rosidl_runtime_c__String description;
  rosidl_runtime_c__String author;
  rosidl_runtime_c__String version;
  rosidl_runtime_c__String function_scope;
  rosidl_runtime_c__String interfaces;
  rosidl_runtime_c__String license;
  vyra_module_interfaces__msg__VBASEKeyValue__Sequence dependencies;
} vyra_module_interfaces__srv__MMRegisterNewModule_Request;

// Struct for a sequence of vyra_module_interfaces__srv__MMRegisterNewModule_Request.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Request__Sequence
{
  vyra_module_interfaces__srv__MMRegisterNewModule_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__MMRegisterNewModule_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'signed_permissions'
// Member 'error_message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MMRegisterNewModule in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Response
{
  int8_t register_status;
  rosidl_runtime_c__String signed_permissions;
  rosidl_runtime_c__String error_message;
} vyra_module_interfaces__srv__MMRegisterNewModule_Response;

// Struct for a sequence of vyra_module_interfaces__srv__MMRegisterNewModule_Response.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Response__Sequence
{
  vyra_module_interfaces__srv__MMRegisterNewModule_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__MMRegisterNewModule_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  vyra_module_interfaces__srv__MMRegisterNewModule_Event__request__MAX_SIZE = 1
};
// response
enum
{
  vyra_module_interfaces__srv__MMRegisterNewModule_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/MMRegisterNewModule in the package vyra_module_interfaces.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Event
{
  service_msgs__msg__ServiceEventInfo info;
  vyra_module_interfaces__srv__MMRegisterNewModule_Request__Sequence request;
  vyra_module_interfaces__srv__MMRegisterNewModule_Response__Sequence response;
} vyra_module_interfaces__srv__MMRegisterNewModule_Event;

// Struct for a sequence of vyra_module_interfaces__srv__MMRegisterNewModule_Event.
typedef struct vyra_module_interfaces__srv__MMRegisterNewModule_Event__Sequence
{
  vyra_module_interfaces__srv__MMRegisterNewModule_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__srv__MMRegisterNewModule_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__STRUCT_H_
