// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:action/VBASEInitiateUpdate.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_H_
#define VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_H_

#include "vyra_module_interfaces/action/detail/vbase_initiate_update__struct.h"
#include "vyra_module_interfaces/action/detail/vbase_initiate_update__functions.h"
#include "vyra_module_interfaces/action/detail/vbase_initiate_update__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__ACTION__VBASE_INITIATE_UPDATE_H_
