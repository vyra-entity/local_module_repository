// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_HPP_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_HPP_

#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__struct.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__builder.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__traits.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_HPP_
