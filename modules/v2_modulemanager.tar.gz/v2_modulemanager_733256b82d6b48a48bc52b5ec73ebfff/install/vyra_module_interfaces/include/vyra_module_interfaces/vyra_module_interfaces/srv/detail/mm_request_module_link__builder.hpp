// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:srv/MMRequestModuleLink.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/mm_request_module_link.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REQUEST_MODULE_LINK__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REQUEST_MODULE_LINK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/srv/detail/mm_request_module_link__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRequestModuleLink_Request_password
{
public:
  explicit Init_MMRequestModuleLink_Request_password(::vyra_module_interfaces::srv::MMRequestModuleLink_Request & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request password(::vyra_module_interfaces::srv::MMRequestModuleLink_Request::_password_type arg)
  {
    msg_.password = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request msg_;
};

class Init_MMRequestModuleLink_Request_username
{
public:
  explicit Init_MMRequestModuleLink_Request_username(::vyra_module_interfaces::srv::MMRequestModuleLink_Request & msg)
  : msg_(msg)
  {}
  Init_MMRequestModuleLink_Request_password username(::vyra_module_interfaces::srv::MMRequestModuleLink_Request::_username_type arg)
  {
    msg_.username = std::move(arg);
    return Init_MMRequestModuleLink_Request_password(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request msg_;
};

class Init_MMRequestModuleLink_Request_function_scope
{
public:
  explicit Init_MMRequestModuleLink_Request_function_scope(::vyra_module_interfaces::srv::MMRequestModuleLink_Request & msg)
  : msg_(msg)
  {}
  Init_MMRequestModuleLink_Request_username function_scope(::vyra_module_interfaces::srv::MMRequestModuleLink_Request::_function_scope_type arg)
  {
    msg_.function_scope = std::move(arg);
    return Init_MMRequestModuleLink_Request_username(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request msg_;
};

class Init_MMRequestModuleLink_Request_module_name
{
public:
  explicit Init_MMRequestModuleLink_Request_module_name(::vyra_module_interfaces::srv::MMRequestModuleLink_Request & msg)
  : msg_(msg)
  {}
  Init_MMRequestModuleLink_Request_function_scope module_name(::vyra_module_interfaces::srv::MMRequestModuleLink_Request::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_MMRequestModuleLink_Request_function_scope(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request msg_;
};

class Init_MMRequestModuleLink_Request_module_id
{
public:
  Init_MMRequestModuleLink_Request_module_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRequestModuleLink_Request_module_name module_id(::vyra_module_interfaces::srv::MMRequestModuleLink_Request::_module_id_type arg)
  {
    msg_.module_id = std::move(arg);
    return Init_MMRequestModuleLink_Request_module_name(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRequestModuleLink_Request>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRequestModuleLink_Request_module_id();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRequestModuleLink_Response_signed_permission_file
{
public:
  explicit Init_MMRequestModuleLink_Response_signed_permission_file(::vyra_module_interfaces::srv::MMRequestModuleLink_Response & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Response signed_permission_file(::vyra_module_interfaces::srv::MMRequestModuleLink_Response::_signed_permission_file_type arg)
  {
    msg_.signed_permission_file = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Response msg_;
};

class Init_MMRequestModuleLink_Response_error_message
{
public:
  explicit Init_MMRequestModuleLink_Response_error_message(::vyra_module_interfaces::srv::MMRequestModuleLink_Response & msg)
  : msg_(msg)
  {}
  Init_MMRequestModuleLink_Response_signed_permission_file error_message(::vyra_module_interfaces::srv::MMRequestModuleLink_Response::_error_message_type arg)
  {
    msg_.error_message = std::move(arg);
    return Init_MMRequestModuleLink_Response_signed_permission_file(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Response msg_;
};

class Init_MMRequestModuleLink_Response_link_status
{
public:
  Init_MMRequestModuleLink_Response_link_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRequestModuleLink_Response_error_message link_status(::vyra_module_interfaces::srv::MMRequestModuleLink_Response::_link_status_type arg)
  {
    msg_.link_status = std::move(arg);
    return Init_MMRequestModuleLink_Response_error_message(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRequestModuleLink_Response>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRequestModuleLink_Response_link_status();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_MMRequestModuleLink_Event_response
{
public:
  explicit Init_MMRequestModuleLink_Event_response(::vyra_module_interfaces::srv::MMRequestModuleLink_Event & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Event response(::vyra_module_interfaces::srv::MMRequestModuleLink_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Event msg_;
};

class Init_MMRequestModuleLink_Event_request
{
public:
  explicit Init_MMRequestModuleLink_Event_request(::vyra_module_interfaces::srv::MMRequestModuleLink_Event & msg)
  : msg_(msg)
  {}
  Init_MMRequestModuleLink_Event_response request(::vyra_module_interfaces::srv::MMRequestModuleLink_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MMRequestModuleLink_Event_response(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Event msg_;
};

class Init_MMRequestModuleLink_Event_info
{
public:
  Init_MMRequestModuleLink_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MMRequestModuleLink_Event_request info(::vyra_module_interfaces::srv::MMRequestModuleLink_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MMRequestModuleLink_Event_request(msg_);
  }

private:
  ::vyra_module_interfaces::srv::MMRequestModuleLink_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::MMRequestModuleLink_Event>()
{
  return vyra_module_interfaces::srv::builder::Init_MMRequestModuleLink_Event_info();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REQUEST_MODULE_LINK__BUILDER_HPP_
