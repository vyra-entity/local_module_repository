// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from vyra_module_interfaces:srv/MMRegisterNewModule.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/mm_register_new_module.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__TRAITS_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "vyra_module_interfaces/srv/detail/mm_register_new_module__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'dependencies'
#include "vyra_module_interfaces/msg/detail/vbase_key_value__traits.hpp"

namespace vyra_module_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const MMRegisterNewModule_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: module_id
  {
    out << "module_id: ";
    rosidl_generator_traits::value_to_yaml(msg.module_id, out);
    out << ", ";
  }

  // member: module_name
  {
    out << "module_name: ";
    rosidl_generator_traits::value_to_yaml(msg.module_name, out);
    out << ", ";
  }

  // member: description
  {
    out << "description: ";
    rosidl_generator_traits::value_to_yaml(msg.description, out);
    out << ", ";
  }

  // member: author
  {
    out << "author: ";
    rosidl_generator_traits::value_to_yaml(msg.author, out);
    out << ", ";
  }

  // member: version
  {
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << ", ";
  }

  // member: function_scope
  {
    out << "function_scope: ";
    rosidl_generator_traits::value_to_yaml(msg.function_scope, out);
    out << ", ";
  }

  // member: interfaces
  {
    out << "interfaces: ";
    rosidl_generator_traits::value_to_yaml(msg.interfaces, out);
    out << ", ";
  }

  // member: license
  {
    out << "license: ";
    rosidl_generator_traits::value_to_yaml(msg.license, out);
    out << ", ";
  }

  // member: dependencies
  {
    if (msg.dependencies.size() == 0) {
      out << "dependencies: []";
    } else {
      out << "dependencies: [";
      size_t pending_items = msg.dependencies.size();
      for (auto item : msg.dependencies) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MMRegisterNewModule_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: module_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "module_id: ";
    rosidl_generator_traits::value_to_yaml(msg.module_id, out);
    out << "\n";
  }

  // member: module_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "module_name: ";
    rosidl_generator_traits::value_to_yaml(msg.module_name, out);
    out << "\n";
  }

  // member: description
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "description: ";
    rosidl_generator_traits::value_to_yaml(msg.description, out);
    out << "\n";
  }

  // member: author
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "author: ";
    rosidl_generator_traits::value_to_yaml(msg.author, out);
    out << "\n";
  }

  // member: version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << "\n";
  }

  // member: function_scope
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "function_scope: ";
    rosidl_generator_traits::value_to_yaml(msg.function_scope, out);
    out << "\n";
  }

  // member: interfaces
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "interfaces: ";
    rosidl_generator_traits::value_to_yaml(msg.interfaces, out);
    out << "\n";
  }

  // member: license
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "license: ";
    rosidl_generator_traits::value_to_yaml(msg.license, out);
    out << "\n";
  }

  // member: dependencies
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dependencies.size() == 0) {
      out << "dependencies: []\n";
    } else {
      out << "dependencies:\n";
      for (auto item : msg.dependencies) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MMRegisterNewModule_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace vyra_module_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use vyra_module_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  vyra_module_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use vyra_module_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const vyra_module_interfaces::srv::MMRegisterNewModule_Request & msg)
{
  return vyra_module_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<vyra_module_interfaces::srv::MMRegisterNewModule_Request>()
{
  return "vyra_module_interfaces::srv::MMRegisterNewModule_Request";
}

template<>
inline const char * name<vyra_module_interfaces::srv::MMRegisterNewModule_Request>()
{
  return "vyra_module_interfaces/srv/MMRegisterNewModule_Request";
}

template<>
struct has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<vyra_module_interfaces::srv::MMRegisterNewModule_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace vyra_module_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const MMRegisterNewModule_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: register_status
  {
    out << "register_status: ";
    rosidl_generator_traits::value_to_yaml(msg.register_status, out);
    out << ", ";
  }

  // member: signed_permissions
  {
    out << "signed_permissions: ";
    rosidl_generator_traits::value_to_yaml(msg.signed_permissions, out);
    out << ", ";
  }

  // member: error_message
  {
    out << "error_message: ";
    rosidl_generator_traits::value_to_yaml(msg.error_message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MMRegisterNewModule_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: register_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "register_status: ";
    rosidl_generator_traits::value_to_yaml(msg.register_status, out);
    out << "\n";
  }

  // member: signed_permissions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "signed_permissions: ";
    rosidl_generator_traits::value_to_yaml(msg.signed_permissions, out);
    out << "\n";
  }

  // member: error_message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_message: ";
    rosidl_generator_traits::value_to_yaml(msg.error_message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MMRegisterNewModule_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace vyra_module_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use vyra_module_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const vyra_module_interfaces::srv::MMRegisterNewModule_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  vyra_module_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use vyra_module_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const vyra_module_interfaces::srv::MMRegisterNewModule_Response & msg)
{
  return vyra_module_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<vyra_module_interfaces::srv::MMRegisterNewModule_Response>()
{
  return "vyra_module_interfaces::srv::MMRegisterNewModule_Response";
}

template<>
inline const char * name<vyra_module_interfaces::srv::MMRegisterNewModule_Response>()
{
  return "vyra_module_interfaces/srv/MMRegisterNewModule_Response";
}

template<>
struct has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<vyra_module_interfaces::srv::MMRegisterNewModule_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__traits.hpp"

namespace vyra_module_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const MMRegisterNewModule_Event & msg,
  std::ostream & out)
{
  out << "{";
  // member: info
  {
    out << "info: ";
    to_flow_style_yaml(msg.info, out);
    out << ", ";
  }

  // member: request
  {
    if (msg.request.size() == 0) {
      out << "request: []";
    } else {
      out << "request: [";
      size_t pending_items = msg.request.size();
      for (auto item : msg.request) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: response
  {
    if (msg.response.size() == 0) {
      out << "response: []";
    } else {
      out << "response: [";
      size_t pending_items = msg.response.size();
      for (auto item : msg.response) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MMRegisterNewModule_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "info:\n";
    to_block_style_yaml(msg.info, out, indentation + 2);
  }

  // member: request
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.request.size() == 0) {
      out << "request: []\n";
    } else {
      out << "request:\n";
      for (auto item : msg.request) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: response
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.response.size() == 0) {
      out << "response: []\n";
    } else {
      out << "response:\n";
      for (auto item : msg.response) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MMRegisterNewModule_Event & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace vyra_module_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use vyra_module_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const vyra_module_interfaces::srv::MMRegisterNewModule_Event & msg,
  std::ostream & out, size_t indentation = 0)
{
  vyra_module_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use vyra_module_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const vyra_module_interfaces::srv::MMRegisterNewModule_Event & msg)
{
  return vyra_module_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<vyra_module_interfaces::srv::MMRegisterNewModule_Event>()
{
  return "vyra_module_interfaces::srv::MMRegisterNewModule_Event";
}

template<>
inline const char * name<vyra_module_interfaces::srv::MMRegisterNewModule_Event>()
{
  return "vyra_module_interfaces/srv/MMRegisterNewModule_Event";
}

template<>
struct has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule_Event>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Event>
  : std::integral_constant<bool, has_bounded_size<service_msgs::msg::ServiceEventInfo>::value && has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Request>::value && has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Response>::value> {};

template<>
struct is_message<vyra_module_interfaces::srv::MMRegisterNewModule_Event>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<vyra_module_interfaces::srv::MMRegisterNewModule>()
{
  return "vyra_module_interfaces::srv::MMRegisterNewModule";
}

template<>
inline const char * name<vyra_module_interfaces::srv::MMRegisterNewModule>()
{
  return "vyra_module_interfaces/srv/MMRegisterNewModule";
}

template<>
struct has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule>
  : std::integral_constant<
    bool,
    has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule_Request>::value &&
    has_fixed_size<vyra_module_interfaces::srv::MMRegisterNewModule_Response>::value
  >
{
};

template<>
struct has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule>
  : std::integral_constant<
    bool,
    has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Request>::value &&
    has_bounded_size<vyra_module_interfaces::srv::MMRegisterNewModule_Response>::value
  >
{
};

template<>
struct is_service<vyra_module_interfaces::srv::MMRegisterNewModule>
  : std::true_type
{
};

template<>
struct is_service_request<vyra_module_interfaces::srv::MMRegisterNewModule_Request>
  : std::true_type
{
};

template<>
struct is_service_response<vyra_module_interfaces::srv::MMRegisterNewModule_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__MM_REGISTER_NEW_MODULE__TRAITS_HPP_
