// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:srv/VBASEHealthCheck.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/vbase_health_check.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_HEALTH_CHECK__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_HEALTH_CHECK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/srv/detail/vbase_health_check__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEHealthCheck_Request>()
{
  return ::vyra_module_interfaces::srv::VBASEHealthCheck_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEHealthCheck_Response_issues
{
public:
  explicit Init_VBASEHealthCheck_Response_issues(::vyra_module_interfaces::srv::VBASEHealthCheck_Response & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Response issues(::vyra_module_interfaces::srv::VBASEHealthCheck_Response::_issues_type arg)
  {
    msg_.issues = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Response msg_;
};

class Init_VBASEHealthCheck_Response_health_status
{
public:
  explicit Init_VBASEHealthCheck_Response_health_status(::vyra_module_interfaces::srv::VBASEHealthCheck_Response & msg)
  : msg_(msg)
  {}
  Init_VBASEHealthCheck_Response_issues health_status(::vyra_module_interfaces::srv::VBASEHealthCheck_Response::_health_status_type arg)
  {
    msg_.health_status = std::move(arg);
    return Init_VBASEHealthCheck_Response_issues(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Response msg_;
};

class Init_VBASEHealthCheck_Response_state
{
public:
  explicit Init_VBASEHealthCheck_Response_state(::vyra_module_interfaces::srv::VBASEHealthCheck_Response & msg)
  : msg_(msg)
  {}
  Init_VBASEHealthCheck_Response_health_status state(::vyra_module_interfaces::srv::VBASEHealthCheck_Response::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_VBASEHealthCheck_Response_health_status(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Response msg_;
};

class Init_VBASEHealthCheck_Response_alive
{
public:
  Init_VBASEHealthCheck_Response_alive()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEHealthCheck_Response_state alive(::vyra_module_interfaces::srv::VBASEHealthCheck_Response::_alive_type arg)
  {
    msg_.alive = std::move(arg);
    return Init_VBASEHealthCheck_Response_state(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEHealthCheck_Response>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEHealthCheck_Response_alive();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEHealthCheck_Event_response
{
public:
  explicit Init_VBASEHealthCheck_Event_response(::vyra_module_interfaces::srv::VBASEHealthCheck_Event & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Event response(::vyra_module_interfaces::srv::VBASEHealthCheck_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Event msg_;
};

class Init_VBASEHealthCheck_Event_request
{
public:
  explicit Init_VBASEHealthCheck_Event_request(::vyra_module_interfaces::srv::VBASEHealthCheck_Event & msg)
  : msg_(msg)
  {}
  Init_VBASEHealthCheck_Event_response request(::vyra_module_interfaces::srv::VBASEHealthCheck_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_VBASEHealthCheck_Event_response(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Event msg_;
};

class Init_VBASEHealthCheck_Event_info
{
public:
  Init_VBASEHealthCheck_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEHealthCheck_Event_request info(::vyra_module_interfaces::srv::VBASEHealthCheck_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_VBASEHealthCheck_Event_request(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEHealthCheck_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEHealthCheck_Event>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEHealthCheck_Event_info();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_HEALTH_CHECK__BUILDER_HPP_
