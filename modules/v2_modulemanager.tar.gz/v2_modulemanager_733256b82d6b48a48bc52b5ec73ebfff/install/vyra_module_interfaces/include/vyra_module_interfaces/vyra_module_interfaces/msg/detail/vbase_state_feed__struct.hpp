// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from vyra_module_interfaces:msg/VBASEStateFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_state_feed.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__STRUCT_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__msg__VBASEStateFeed __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__msg__VBASEStateFeed __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VBASEStateFeed_
{
  using Type = VBASEStateFeed_<ContainerAllocator>;

  explicit VBASEStateFeed_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->previous = "";
      this->current = "";
      this->trigger = "";
      this->module_id = "";
      this->module_name = "";
    }
  }

  explicit VBASEStateFeed_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : previous(_alloc),
    current(_alloc),
    trigger(_alloc),
    module_id(_alloc),
    module_name(_alloc),
    timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->previous = "";
      this->current = "";
      this->trigger = "";
      this->module_id = "";
      this->module_name = "";
    }
  }

  // field types and members
  using _previous_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _previous_type previous;
  using _current_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _current_type current;
  using _trigger_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _trigger_type trigger;
  using _module_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _module_id_type module_id;
  using _module_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _module_name_type module_name;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__previous(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->previous = _arg;
    return *this;
  }
  Type & set__current(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->current = _arg;
    return *this;
  }
  Type & set__trigger(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->trigger = _arg;
    return *this;
  }
  Type & set__module_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->module_id = _arg;
    return *this;
  }
  Type & set__module_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->module_name = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEStateFeed
    std::shared_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEStateFeed
    std::shared_ptr<vyra_module_interfaces::msg::VBASEStateFeed_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASEStateFeed_ & other) const
  {
    if (this->previous != other.previous) {
      return false;
    }
    if (this->current != other.current) {
      return false;
    }
    if (this->trigger != other.trigger) {
      return false;
    }
    if (this->module_id != other.module_id) {
      return false;
    }
    if (this->module_name != other.module_name) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASEStateFeed_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASEStateFeed_

// alias to use template instance with default allocator
using VBASEStateFeed =
  vyra_module_interfaces::msg::VBASEStateFeed_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__STRUCT_HPP_
