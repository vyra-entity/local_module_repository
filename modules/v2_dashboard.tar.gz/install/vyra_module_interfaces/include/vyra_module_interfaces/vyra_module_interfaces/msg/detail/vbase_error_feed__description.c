// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:msg/VBASEErrorFeed.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/msg/detail/vbase_error_feed__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__msg__VBASEErrorFeed__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x41, 0xd4, 0x1b, 0x8d, 0x63, 0x47, 0xbd, 0x0e,
      0x2d, 0x16, 0xb7, 0x88, 0x51, 0x33, 0xd5, 0xeb,
      0x37, 0x32, 0x25, 0x56, 0x81, 0xb9, 0xd8, 0x66,
      0x91, 0xc5, 0xbf, 0xd9, 0x1d, 0xb7, 0xbc, 0xf9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"
#include "unique_identifier_msgs/msg/detail/uuid__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t unique_identifier_msgs__msg__UUID__EXPECTED_HASH = {1, {
    0x1b, 0x8e, 0x8a, 0xca, 0x95, 0x8c, 0xbe, 0xa2,
    0x8f, 0xe6, 0xef, 0x60, 0xbf, 0x6c, 0x19, 0xb6,
    0x83, 0xc9, 0x7a, 0x9e, 0xf6, 0x0b, 0xb3, 0x47,
    0x52, 0x06, 0x7d, 0x0f, 0x2f, 0x7a, 0xb4, 0x37,
  }};
#endif

static char vyra_module_interfaces__msg__VBASEErrorFeed__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEErrorFeed";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char unique_identifier_msgs__msg__UUID__TYPE_NAME[] = "unique_identifier_msgs/msg/UUID";

// Define type names, field names, and default values
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__level[] = "level";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__code[] = "code";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__uuid[] = "uuid";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__timestamp[] = "timestamp";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__description[] = "description";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__solution[] = "solution";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__miscellaneous[] = "miscellaneous";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__module_name[] = "module_name";
static char vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__module_id[] = "module_id";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__msg__VBASEErrorFeed__FIELDS[] = {
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__level, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__code, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__uuid, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__timestamp, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__description, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__solution, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__miscellaneous, 13, 13},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__module_name, 11, 11},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {vyra_module_interfaces__msg__VBASEErrorFeed__FIELD_NAME__module_id, 9, 9},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__msg__VBASEErrorFeed__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {unique_identifier_msgs__msg__UUID__TYPE_NAME, 31, 31},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__msg__VBASEErrorFeed__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__msg__VBASEErrorFeed__TYPE_NAME, 41, 41},
      {vyra_module_interfaces__msg__VBASEErrorFeed__FIELDS, 9, 9},
    },
    {vyra_module_interfaces__msg__VBASEErrorFeed__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&unique_identifier_msgs__msg__UUID__EXPECTED_HASH, unique_identifier_msgs__msg__UUID__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = unique_identifier_msgs__msg__UUID__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# ErrorFeed.msg\n"
  "\n"
  "uint8 level\n"
  "uint32 code\n"
  "string uuid\n"
  "builtin_interfaces/Time timestamp\n"
  "string description\n"
  "string solution\n"
  "string miscellaneous\n"
  "string module_name\n"
  "unique_identifier_msgs/UUID module_id\n"
  "\n"
  "# The error code representing the specific error\n"
  "# A description of the error\n"
  "# A list of asset IDs related to the error\n"
  "# The timestamp when the error occurred\n"
  "# This message is used to communicate error information in the system\n"
  "# between different components or modules.\n"
  "# It can be used for logging, debugging, or alerting purposes.\n"
  "# The error_code is a unique identifier for the error type (hex-foramt).\n"
  "# The error_description provides additional context about the error.\n"
  "# The assets array contains objects (e.g., pictures) to illustrate the error.";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__msg__VBASEErrorFeed__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__msg__VBASEErrorFeed__TYPE_NAME, 41, 41},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 758, 758},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__msg__VBASEErrorFeed__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__msg__VBASEErrorFeed__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *unique_identifier_msgs__msg__UUID__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
