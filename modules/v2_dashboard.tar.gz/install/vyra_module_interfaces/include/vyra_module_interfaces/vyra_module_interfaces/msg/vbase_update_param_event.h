// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:msg/VBASEUpdateParamEvent.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_H_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_H_

#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__struct.h"
#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_UPDATE_PARAM_EVENT_H_
