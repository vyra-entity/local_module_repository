// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from vyra_module_interfaces:msg/VBASEErrorFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_error_feed.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"
// Member 'module_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__msg__VBASEErrorFeed __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__msg__VBASEErrorFeed __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VBASEErrorFeed_
{
  using Type = VBASEErrorFeed_<ContainerAllocator>;

  explicit VBASEErrorFeed_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init),
    module_id(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->level = 0;
      this->code = 0ul;
      this->uuid = "";
      this->description = "";
      this->solution = "";
      this->miscellaneous = "";
      this->module_name = "";
    }
  }

  explicit VBASEErrorFeed_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : uuid(_alloc),
    timestamp(_alloc, _init),
    description(_alloc),
    solution(_alloc),
    miscellaneous(_alloc),
    module_name(_alloc),
    module_id(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->level = 0;
      this->code = 0ul;
      this->uuid = "";
      this->description = "";
      this->solution = "";
      this->miscellaneous = "";
      this->module_name = "";
    }
  }

  // field types and members
  using _level_type =
    uint8_t;
  _level_type level;
  using _code_type =
    uint32_t;
  _code_type code;
  using _uuid_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _uuid_type uuid;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _description_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _description_type description;
  using _solution_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _solution_type solution;
  using _miscellaneous_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _miscellaneous_type miscellaneous;
  using _module_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _module_name_type module_name;
  using _module_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _module_id_type module_id;

  // setters for named parameter idiom
  Type & set__level(
    const uint8_t & _arg)
  {
    this->level = _arg;
    return *this;
  }
  Type & set__code(
    const uint32_t & _arg)
  {
    this->code = _arg;
    return *this;
  }
  Type & set__uuid(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->uuid = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__description(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->description = _arg;
    return *this;
  }
  Type & set__solution(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->solution = _arg;
    return *this;
  }
  Type & set__miscellaneous(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->miscellaneous = _arg;
    return *this;
  }
  Type & set__module_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->module_name = _arg;
    return *this;
  }
  Type & set__module_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->module_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEErrorFeed
    std::shared_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEErrorFeed
    std::shared_ptr<vyra_module_interfaces::msg::VBASEErrorFeed_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASEErrorFeed_ & other) const
  {
    if (this->level != other.level) {
      return false;
    }
    if (this->code != other.code) {
      return false;
    }
    if (this->uuid != other.uuid) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->description != other.description) {
      return false;
    }
    if (this->solution != other.solution) {
      return false;
    }
    if (this->miscellaneous != other.miscellaneous) {
      return false;
    }
    if (this->module_name != other.module_name) {
      return false;
    }
    if (this->module_id != other.module_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASEErrorFeed_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASEErrorFeed_

// alias to use template instance with default allocator
using VBASEErrorFeed =
  vyra_module_interfaces::msg::VBASEErrorFeed_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_ERROR_FEED__STRUCT_HPP_
