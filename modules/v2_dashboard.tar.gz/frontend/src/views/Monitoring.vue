<template>
  <div class="monitoring-view">
    <!-- System Overview -->
    <div class="grid">
      <div class="col-12 lg:col-8">
        <Card>
          <template #title>
            <i class="pi pi-chart-line"></i> System Performance
          </template>
          <template #content>
            <Chart type="line" :data="performanceData" :options="chartOptions" />
          </template>
        </Card>
      </div>

      <div class="col-12 lg:col-4">
        <Card>
          <template #title>
            <i class="pi pi-server"></i> Ressourcen
          </template>
          <template #content>
            <div class="flex flex-column gap-4">
              <div>
                <div class="flex justify-content-between mb-2">
                  <span class="font-semibold">CPU Auslastung</span>
                  <span>{{ systemStats.cpu }}%</span>
                </div>
                <ProgressBar :value="systemStats.cpu" :showValue="false" />
              </div>

              <div>
                <div class="flex justify-content-between mb-2">
                  <span class="font-semibold">RAM Auslastung</span>
                  <span>{{ systemStats.ram }}%</span>
                </div>
                <ProgressBar :value="systemStats.ram" :showValue="false" />
              </div>

              <div>
                <div class="flex justify-content-between mb-2">
                  <span class="font-semibold">Disk Usage</span>
                  <span>{{ systemStats.disk }}%</span>
                </div>
                <ProgressBar :value="systemStats.disk" :showValue="false" />
              </div>

              <div>
                <div class="flex justify-content-between mb-2">
                  <span class="font-semibold">Network</span>
                  <span>{{ systemStats.network }} MB/s</span>
                </div>
                <ProgressBar :value="systemStats.networkPercent" :showValue="false" />
              </div>
            </div>
          </template>
        </Card>
      </div>
    </div>

    <!-- Module Status -->
    <div class="grid mt-4">
      <div class="col-12 lg:col-6">
        <Card>
          <template #title>
            <i class="pi pi-box"></i> Module Status
          </template>
          <template #content>
            <Chart type="doughnut" :data="moduleStatusData" :options="doughnutOptions" />
          </template>
        </Card>
      </div>

      <div class="col-12 lg:col-6">
        <Card>
          <template #title>
            <i class="pi pi-chart-bar"></i> Memory Verteilung
          </template>
          <template #content>
            <Chart type="bar" :data="memoryData" :options="barOptions" />
          </template>
        </Card>
      </div>
    </div>

    <!-- System Logs -->
    <Card class="mt-4">
      <template #title>
        <div class="flex align-items-center justify-content-between">
          <span><i class="pi pi-list"></i> System Logs</span>
          <div class="flex gap-2">
            <Button label="Aktualisieren" icon="pi pi-refresh" size="small" @click="refreshLogs" />
            <Button label="Exportieren" icon="pi pi-download" size="small" severity="secondary" />
          </div>
        </div>
      </template>
      <template #content>
        <DataTable 
          :value="logs" 
          :paginator="true" 
          :rows="5" 
          stripedRows
          class="p-datatable-sm"
        >
          <Column field="timestamp" header="Zeit" style="width: 12rem" />
          <Column field="level" header="Level" style="width: 8rem">
            <template #body="{ data }">
              <Tag :value="data.level" :severity="getLogSeverity(data.level)" />
            </template>
          </Column>
          <Column field="module" header="Modul" style="width: 12rem" />
          <Column field="message" header="Nachricht" />
        </DataTable>
      </template>
    </Card>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import Card from 'primevue/card'
import Chart from 'primevue/chart'
import ProgressBar from 'primevue/progressbar'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Button from 'primevue/button'
import Tag from 'primevue/tag'

const systemStats = ref({
  cpu: 42,
  ram: 68,
  disk: 55,
  network: 12.5,
  networkPercent: 25
})

const performanceData = ref({
  labels: ['10:00', '10:05', '10:10', '10:15', '10:20', '10:25', '10:30'],
  datasets: [
    {
      label: 'CPU %',
      data: [35, 42, 38, 45, 42, 40, 42],
      borderColor: '#3B82F6',
      backgroundColor: 'rgba(59, 130, 246, 0.2)',
      tension: 0.4,
      fill: true
    },
    {
      label: 'Memory %',
      data: [62, 65, 68, 70, 68, 67, 68],
      borderColor: '#8B5CF6',
      backgroundColor: 'rgba(139, 92, 246, 0.2)',
      tension: 0.4,
      fill: true
    }
  ]
})

const moduleStatusData = ref({
  labels: ['Running', 'Stopped', 'Error'],
  datasets: [
    {
      data: [3, 1, 1],
      backgroundColor: ['#10B981', '#F59E0B', '#EF4444']
    }
  ]
})

const memoryData = ref({
  labels: ['v2_dashboard', 'v2_modulemanager', 'vision_module', 'robotics_controller'],
  datasets: [
    {
      label: 'Memory (MB)',
      data: [256, 192, 0, 384],
      backgroundColor: '#3B82F6'
    }
  ]
})

const logs = ref([
  { timestamp: '10:30:15', level: 'INFO', module: 'v2_dashboard', message: 'Dashboard started successfully' },
  { timestamp: '10:29:42', level: 'WARNING', module: 'vision_module', message: 'Camera connection timeout' },
  { timestamp: '10:28:33', level: 'ERROR', module: 'data_logger', message: 'Failed to write to database' },
  { timestamp: '10:27:18', level: 'INFO', module: 'v2_modulemanager', message: 'Module manager initialized' },
  { timestamp: '10:26:05', level: 'INFO', module: 'robotics_controller', message: 'Robot arm calibrated' }
])

const chartOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top'
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      max: 100
    }
  }
})

const doughnutOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom'
    }
  }
})

const barOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    }
  },
  scales: {
    y: {
      beginAtZero: true
    }
  }
})

const getLogSeverity = (level) => {
  switch (level) {
    case 'ERROR': return 'danger'
    case 'WARNING': return 'warning'
    case 'INFO': return 'info'
    default: return 'secondary'
  }
}

const refreshLogs = () => {
  // Simulate new log entry
  logs.value.unshift({
    timestamp: new Date().toLocaleTimeString('de-DE'),
    level: 'INFO',
    module: 'system',
    message: 'Logs refreshed'
  })
}

// Auto-update system stats
let statsInterval = null

onMounted(() => {
  statsInterval = setInterval(() => {
    systemStats.value.cpu = Math.floor(Math.random() * 30) + 30
    systemStats.value.ram = Math.floor(Math.random() * 20) + 60
    systemStats.value.network = (Math.random() * 20 + 5).toFixed(1)
    systemStats.value.networkPercent = Math.floor(systemStats.value.network * 2)
    
    // Update performance chart
    const currentTime = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })
    performanceData.value.labels.push(currentTime)
    performanceData.value.labels.shift()
    
    performanceData.value.datasets[0].data.push(systemStats.value.cpu)
    performanceData.value.datasets[0].data.shift()
    
    performanceData.value.datasets[1].data.push(systemStats.value.ram)
    performanceData.value.datasets[1].data.shift()
  }, 5000)
})

onUnmounted(() => {
  if (statsInterval) {
    clearInterval(statsInterval)
  }
})
</script>

<style scoped>
.monitoring-view {
  animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

:deep(.p-chart) {
  height: 300px;
}
</style>
