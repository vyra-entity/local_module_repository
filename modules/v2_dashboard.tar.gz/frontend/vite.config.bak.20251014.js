// vite.config.js - Für Vite-basierte Vue.js Projekte mit Nginx Support
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  base: process.env.VITE_BASE_URL || '/v2_dashboard/', // 🆕 Base URL für Gateway-Routing (dynamisch)
  server: {
    port: 3000,
    host: '0.0.0.0',
    proxy: {
      // Proxy alle /api Requests zum Backend
      '/api': {
        target: 'https://localhost:8443',
        changeOrigin: true,
        secure: false, // für selbst-signierte Zertifikate
        rewrite: (path) => path.replace(/^\/v2_dashboard\/api/, '')
      }
    }
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    // Optimiert für Nginx Static File Serving
    rollupOptions: {
      output: {
        // Bessere Asset-Namen für Nginx Caching
        assetFileNames: (assetInfo) => {
        //   const info = assetInfo.name.split('.');
        //   const ext = info[info.length - 1];
        //   if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(ext)) {
        //     return `assets/images/[name]-[hash][extname]`;
        //   }
        //   if (/css/i.test(ext)) {
        //     return `assets/css/[name]-[hash][extname]`;
        //   }
        //   if (/woff2?|eot|ttf|otf/i.test(ext)) {
        //     return `assets/fonts/[name]-[hash][extname]`;
        //   }
        //   return `assets/[name]-[hash][extname]`;
        },
        chunkFileNames: 'assets/js/[name]-[hash].js',
        entryFileNames: 'assets/js/[name]-[hash].js'
      }
    },
    // Nginx-optimierte Einstellungen
    target: 'es2015',
    minify: 'esbuild', // Fallback zu esbuild wenn terser nicht verfügbar
    sourcemap: false, // Für Production
    reportCompressedSize: false,
    chunkSizeWarningLimit: 1000
  },
  // Optimierung für Nginx-Caching
  define: {
    __VUE_OPTIONS_API__: true,
    __VUE_PROD_DEVTOOLS__: false
  }
})
