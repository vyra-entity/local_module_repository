#!/bin/bash
export ROS_DOMAIN_ID=0
source /opt/ros/kilted/setup.bash