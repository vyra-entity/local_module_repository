source /workspace/tools/ros/init_ros2.sh
ros2 service call /v2_modulemanager_733256b82d6b48a48bc52b5ec73ebfff/callable/get_interface_list vyra_module_interfaces/srv/VBASEGetInterfaceList "{}"