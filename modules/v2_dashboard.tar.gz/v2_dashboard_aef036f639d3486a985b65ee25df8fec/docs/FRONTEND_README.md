# VYRA Dashboard - Vue.js Frontend Integration

## ✅ Supervisord-basiertes Server-Management

Das VYRA Dashboard verwendet **Supervisord** für das gesamte Server-Management. Frontend (Nginx) und Backend (Uvicorn) werden automatisch über Supervisord gestartet und verwaltet.

## 🚀 Server starten

### Production-Modus (Standard):
```bash
# Container starten - Supervisord übernimmt Server-Management
docker compose up v2_dashboard

# Oder direkt:
./vyra_entrypoint.sh
```

### Development-Modus:
```bash
# Environment-Variable setzen
export VYRA_DEV_MODE=true

# Container starten - Vue Dev Server wird automatisch gestartet
docker compose up v2_dashboard
```

## 🌐 Zugriff

### Mit Traefik Gateway (Production):
- **Frontend URL:** https://localhost/ (via Traefik → Nginx)
- **Backend API:** https://localhost/api/dashboard/* (via Traefik → Uvicorn)
- **API Docs:** https://localhost/api/dashboard/docs

### Direkt (Development):
- **Frontend URL:** https://localhost:3000 (Nginx mit SSL)
- **Backend API:** https://localhost:8443 (Uvicorn mit SSL)
- **Vue Dev Server:** http://localhost:3000 (in DEV_MODE)

## 📁 Datei-Struktur

```
v2_dashboard/
├── nginx.conf              # Nginx Konfiguration (Frontend Reverse Proxy)
├── uvicorn.py             # Uvicorn ASGI Server Konfiguration
├── src/
│   ├── asgi.py            # ASGI Entry Point
│   └── v2_dashboard/v2_dashboard/application/
│       └── minimal_rest.py # FastAPI Backend
├── frontend/               # Vue.js Quellcode
│   ├── src/
│   │   ├── App.vue
│   │   ├── main.js
│   │   └── views/
│   ├── package.json
│   └── vite.config.js     # Base path: '/'
└── vyra_entrypoint.sh     # Container Startup Script
```

## 🔧 Architektur

1. **Traefik Gateway:** Zentraler Reverse Proxy mit TLS Termination
2. **Path-based Routing:** `/` → Dashboard, `/modulemanager/` → Module Manager
3. **API Routing:** `/api/dashboard/*` → Backend (StripPrefix Middleware)
4. **Supervisord:** Process Manager für Nginx, Uvicorn, ROS2
5. **FastAPI/Uvicorn:** Moderne async ASGI-basierte API
- `VYRA_DEV_MODE=true` → Vue Dev Server statt Nginx
- `ENABLE_FRONTEND_WEBSERVER=true` → Nginx aktivieren
- `ENABLE_BACKEND_WEBSERVER=true` → Gunicorn aktivieren
- `MODULE_NAME=v2_dashboard` → Automatisches WSGI-Loading

## 📝 Logs und Debugging

### Supervisord Logs:
```bash
# Alle Services anzeigen
docker exec v2_dashboard supervisorctl status

# Service-spezifische Logs
docker exec v2_dashboard supervisorctl tail nginx
docker exec v2_dashboard supervisorctl tail gunicorn

# Live-Logs verfolgen
docker exec v2_dashboard supervisorctl tail -f nginx
```

### Development-Logs:
- Vue Dev Server: Läuft im Vordergrund mit Hot-Reload-Output
- Backend API: Über Supervisord (siehe oben)

Das Dashboard ist jetzt vollständig supervisord-basiert und bietet sowohl Development- als auch Production-Modi!
