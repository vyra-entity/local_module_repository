<template>
  <div class="vyra-app">
    <Menubar :model="menuItems" class="vyra-menubar">
      <template #start>
        <div class="flex align-items-center gap-2">
          <i class="pi pi-bolt text-2xl text-primary"></i>
          <span class="font-bold text-xl">VYRA Dashboard</span>
          <Badge :value="moduleCount" severity="info" />
        </div>
      </template>
      <template #end>
        <Tag :value="backendStatus" :severity="backendStatus === 'running' ? 'success' : 'danger'" icon="pi pi-circle-fill" />
      </template>
    </Menubar>

    <div class="vyra-content">
      <router-view />
    </div>

    <div class="vyra-footer">
      <span>VYRA Industrial Automation © 2025</span>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import Menubar from 'primevue/menubar'
import Badge from 'primevue/badge'
import Tag from 'primevue/tag'

const router = useRouter()
const moduleCount = ref(3)
const backendStatus = ref('running')

const menuItems = ref([
  {
    label: 'Home',
    icon: 'pi pi-home',
    command: () => router.push('/')
  },
  {
    label: 'Module',
    icon: 'pi pi-box',
    command: () => router.push('/modules')
  },
  {
    label: 'Monitoring',
    icon: 'pi pi-chart-line',
    command: () => router.push('/monitoring')
  },
  {
    label: 'Demo',
    icon: 'pi pi-star',
    command: () => router.push('/primevue-demo')
  }
])
</script>

<style scoped>
.vyra-app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: var(--surface-ground);
}

.vyra-menubar {
  border-radius: 0;
  border-left: none;
  border-right: none;
  border-top: none;
}

.vyra-content {
  flex: 1;
  padding: 2rem;
  max-width: 1400px;
  width: 100%;
  margin: 0 auto;
  overflow: hidden;
  box-sizing: border-box;
}

.vyra-footer {
  text-align: center;
  padding: 1.5rem;
  background: var(--surface-section);
  border-top: 1px solid var(--surface-border);
  color: var(--text-color-secondary);
}
</style>
