<template>
  <div class="primevue-demo">
    <Card>
      <template #title>
        <i class="pi pi-sparkles"></i> PrimeVue Komponenten Demo
      </template>
      <template #content>
        <TabView>
          <TabPanel header="Buttons & Forms">
            <div class="demo-section">
              <h3>Buttons</h3>
              <div class="button-group">
                <Button label="Primary" />
                <Button label="Secondary" severity="secondary" />
                <Button label="Success" severity="success" />
                <Button label="Info" severity="info" />
                <Button label="Warning" severity="warning" />
                <Button label="Danger" severity="danger" />
              </div>

              <h3>Form Controls</h3>
              <div class="form-demo">
                <InputText v-model="demoForm.name" placeholder="Name eingeben" />
                <InputNumber v-model="demoForm.value" placeholder="Wert" />
                <Calendar v-model="demoForm.date" placeholder="Datum wählen" />
                <Dropdown v-model="demoForm.selected" :options="options" optionLabel="name" placeholder="Option wählen" />
              </div>
            </div>
          </TabPanel>

          <TabPanel header="Data Display">
            <div class="demo-section">
              <h3>DataTable</h3>
              <DataTable :value="demoData" :paginator="true" :rows="5" responsiveLayout="scroll">
                <Column field="id" header="ID" sortable />
                <Column field="name" header="Name" sortable />
                <Column field="status" header="Status">
                  <template #body="slotProps">
                    <Tag :value="slotProps.data.status" :severity="getStatusSeverity(slotProps.data.status)" />
                  </template>
                </Column>
                <Column field="value" header="Wert" sortable />
              </DataTable>
            </div>
          </TabPanel>

          <TabPanel header="Charts & Visualizations">
            <div class="demo-section">
              <h3>Chart.js Integration</h3>
              <Chart type="line" :data="chartData" :options="chartOptions" />
              
              <h3>Progress Components</h3>
              <div class="progress-demo">
                <div>
                  <label>Progress Bar</label>
                  <ProgressBar :value="60" />
                </div>
                <div>
                  <label>Knob</label>
                  <Knob v-model="knobValue" :size="100" />
                </div>
              </div>
            </div>
          </TabPanel>

          <TabPanel header="Overlay & Messages">
            <div class="demo-section">
              <h3>Dialog & Overlay</h3>
              <div class="button-group">
                <Button label="Dialog öffnen" icon="pi pi-external-link" @click="dialogVisible = true" />
                <Button label="Toast anzeigen" icon="pi pi-bell" @click="showToast" />
                <Button label="Confirm" icon="pi pi-question" @click="showConfirm" />
              </div>
            </div>
          </TabPanel>
        </TabView>
      </template>
    </Card>

    <!-- Demo Dialog -->
    <Dialog v-model:visible="dialogVisible" header="PrimeVue Dialog" :modal="true" :style="{ width: '30vw' }">
      <p>Dies ist ein PrimeVue Dialog mit Modal-Overlay.</p>
      <p>Perfekt für Formulare, Bestätigungen und Details.</p>
      <template #footer>
        <Button label="Abbrechen" icon="pi pi-times" text @click="dialogVisible = false" />
        <Button label="Speichern" icon="pi pi-check" @click="dialogVisible = false" />
      </template>
    </Dialog>

    <!-- Toast für Nachrichten -->
    <Toast />

    <!-- Confirm Dialog -->
    <ConfirmDialog />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useToast } from 'primevue/usetoast'
import { useConfirm } from 'primevue/useconfirm'

import Card from 'primevue/card'
import TabView from 'primevue/tabview'
import TabPanel from 'primevue/tabpanel'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import InputNumber from 'primevue/inputnumber'
import Calendar from 'primevue/calendar'
import Dropdown from 'primevue/dropdown'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Tag from 'primevue/tag'
import Chart from 'primevue/chart'
import ProgressBar from 'primevue/progressbar'
import Knob from 'primevue/knob'
import Dialog from 'primevue/dialog'
import Toast from 'primevue/toast'
import ConfirmDialog from 'primevue/confirmdialog'

const toast = useToast()
const confirm = useConfirm()

const dialogVisible = ref(false)
const knobValue = ref(75)

const demoForm = ref({
  name: '',
  value: null,
  date: null,
  selected: null
})

const options = ref([
  { name: 'Option 1', code: 'OPT1' },
  { name: 'Option 2', code: 'OPT2' },
  { name: 'Option 3', code: 'OPT3' }
])

const demoData = ref([
  { id: 1, name: 'Modul A', status: 'active', value: 100 },
  { id: 2, name: 'Modul B', status: 'inactive', value: 75 },
  { id: 3, name: 'Modul C', status: 'active', value: 90 },
  { id: 4, name: 'Modul D', status: 'error', value: 45 },
  { id: 5, name: 'Modul E', status: 'active', value: 85 }
])

const chartData = ref({
  labels: ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun'],
  datasets: [
    {
      label: 'Performance',
      data: [65, 59, 80, 81, 56, 55],
      fill: false,
      borderColor: '#42A5F5',
      tension: 0.4
    }
  ]
})

const chartOptions = ref({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top'
    }
  }
})

const getStatusSeverity = (status) => {
  switch (status) {
    case 'active': return 'success'
    case 'inactive': return 'warning'
    case 'error': return 'danger'
    default: return 'info'
  }
}

const showToast = () => {
  toast.add({
    severity: 'success',
    summary: 'Erfolg',
    detail: 'PrimeVue Toast Nachricht',
    life: 3000
  })
}

const showConfirm = () => {
  confirm.require({
    message: 'Möchten Sie diese Aktion wirklich ausführen?',
    header: 'Bestätigung',
    icon: 'pi pi-exclamation-triangle',
    accept: () => {
      toast.add({
        severity: 'info',
        summary: 'Bestätigt',
        detail: 'Sie haben bestätigt',
        life: 3000
      })
    },
    reject: () => {
      toast.add({
        severity: 'error',
        summary: 'Abgelehnt',
        detail: 'Sie haben abgelehnt',
        life: 3000
      })
    }
  })
}
</script>

<style scoped>
.primevue-demo {
  margin: 2rem 0;
}

.demo-section {
  padding: 1rem 0;
}

.demo-section h3 {
  margin: 1.5rem 0 1rem 0;
  color: #2c3e50;
}

.button-group {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
  margin-bottom: 1.5rem;
}

.form-demo {
  display: grid;
  gap: 1rem;
  max-width: 500px;
}

.progress-demo {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 2rem;
  align-items: center;
  margin-top: 1rem;
}

.progress-demo > div {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
</style>
