// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:srv/VBASEGetUpdateParamEventTopic.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC_H_
#define VYRA_MODULE_INTERFACES__SRV__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC_H_

#include "vyra_module_interfaces/srv/detail/vbase_get_update_param_event_topic__struct.h"
#include "vyra_module_interfaces/srv/detail/vbase_get_update_param_event_topic__functions.h"
#include "vyra_module_interfaces/srv/detail/vbase_get_update_param_event_topic__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__SRV__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC_H_
