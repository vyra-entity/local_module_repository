// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from vyra_module_interfaces:msg/VBASEUpdateParamEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_update_param_event.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__msg__VBASEUpdateParamEvent __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__msg__VBASEUpdateParamEvent __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VBASEUpdateParamEvent_
{
  using Type = VBASEUpdateParamEvent_<ContainerAllocator>;

  explicit VBASEUpdateParamEvent_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->param_key = "";
      this->changed_from = "";
      this->changed_to = "";
      this->id = "";
    }
  }

  explicit VBASEUpdateParamEvent_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : param_key(_alloc),
    changed_from(_alloc),
    changed_to(_alloc),
    id(_alloc),
    timestamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->param_key = "";
      this->changed_from = "";
      this->changed_to = "";
      this->id = "";
    }
  }

  // field types and members
  using _param_key_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _param_key_type param_key;
  using _changed_from_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _changed_from_type changed_from;
  using _changed_to_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _changed_to_type changed_to;
  using _id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _id_type id;
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;

  // setters for named parameter idiom
  Type & set__param_key(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->param_key = _arg;
    return *this;
  }
  Type & set__changed_from(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->changed_from = _arg;
    return *this;
  }
  Type & set__changed_to(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->changed_to = _arg;
    return *this;
  }
  Type & set__id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEUpdateParamEvent
    std::shared_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__msg__VBASEUpdateParamEvent
    std::shared_ptr<vyra_module_interfaces::msg::VBASEUpdateParamEvent_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASEUpdateParamEvent_ & other) const
  {
    if (this->param_key != other.param_key) {
      return false;
    }
    if (this->changed_from != other.changed_from) {
      return false;
    }
    if (this->changed_to != other.changed_to) {
      return false;
    }
    if (this->id != other.id) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASEUpdateParamEvent_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASEUpdateParamEvent_

// alias to use template instance with default allocator
using VBASEUpdateParamEvent =
  vyra_module_interfaces::msg::VBASEUpdateParamEvent_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_HPP_
