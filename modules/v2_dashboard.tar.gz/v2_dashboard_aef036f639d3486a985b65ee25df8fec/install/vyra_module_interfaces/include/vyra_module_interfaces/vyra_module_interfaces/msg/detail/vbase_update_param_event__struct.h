// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:msg/VBASEUpdateParamEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_update_param_event.h"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_H_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'param_key'
// Member 'changed_from'
// Member 'changed_to'
// Member 'id'
#include "rosidl_runtime_c/string.h"
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/VBASEUpdateParamEvent in the package vyra_module_interfaces.
/**
  * VBASEUpdateParamEvent.msg
 */
typedef struct vyra_module_interfaces__msg__VBASEUpdateParamEvent
{
  rosidl_runtime_c__String param_key;
  rosidl_runtime_c__String changed_from;
  rosidl_runtime_c__String changed_to;
  rosidl_runtime_c__String id;
  builtin_interfaces__msg__Time timestamp;
} vyra_module_interfaces__msg__VBASEUpdateParamEvent;

// Struct for a sequence of vyra_module_interfaces__msg__VBASEUpdateParamEvent.
typedef struct vyra_module_interfaces__msg__VBASEUpdateParamEvent__Sequence
{
  vyra_module_interfaces__msg__VBASEUpdateParamEvent * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__msg__VBASEUpdateParamEvent__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__STRUCT_H_
