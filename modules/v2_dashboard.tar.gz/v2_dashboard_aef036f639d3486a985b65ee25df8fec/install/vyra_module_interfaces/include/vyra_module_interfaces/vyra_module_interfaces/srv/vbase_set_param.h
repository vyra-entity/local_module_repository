// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:srv/VBASESetParam.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__VBASE_SET_PARAM_H_
#define VYRA_MODULE_INTERFACES__SRV__VBASE_SET_PARAM_H_

#include "vyra_module_interfaces/srv/detail/vbase_set_param__struct.h"
#include "vyra_module_interfaces/srv/detail/vbase_set_param__functions.h"
#include "vyra_module_interfaces/srv/detail/vbase_set_param__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__SRV__VBASE_SET_PARAM_H_
