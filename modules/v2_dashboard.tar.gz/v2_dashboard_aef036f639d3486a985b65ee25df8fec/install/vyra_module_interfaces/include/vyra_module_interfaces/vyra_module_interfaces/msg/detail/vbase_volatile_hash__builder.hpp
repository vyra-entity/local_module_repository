// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASEVolatileHash.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_volatile_hash.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_volatile_hash__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASEVolatileHash_entries
{
public:
  Init_VBASEVolatileHash_entries()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::vyra_module_interfaces::msg::VBASEVolatileHash entries(::vyra_module_interfaces::msg::VBASEVolatileHash::_entries_type arg)
  {
    msg_.entries = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEVolatileHash msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASEVolatileHash>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASEVolatileHash_entries();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_VOLATILE_HASH__BUILDER_HPP_
