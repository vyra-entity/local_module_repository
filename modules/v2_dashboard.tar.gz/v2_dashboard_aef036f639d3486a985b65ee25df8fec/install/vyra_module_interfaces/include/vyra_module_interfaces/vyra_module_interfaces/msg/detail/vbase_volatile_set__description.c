// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:msg/VBASEVolatileSet.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/msg/detail/vbase_volatile_set__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__msg__VBASEVolatileSet__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xc4, 0x62, 0x0e, 0xce, 0xfc, 0x2b, 0x5c, 0x8b,
      0x4a, 0x36, 0xf2, 0xdf, 0x58, 0x37, 0x06, 0xd8,
      0xb0, 0x34, 0x26, 0x0c, 0x47, 0x25, 0x89, 0xf9,
      0x69, 0x6b, 0xda, 0x6a, 0xda, 0x40, 0x71, 0x2d,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char vyra_module_interfaces__msg__VBASEVolatileSet__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEVolatileSet";

// Define type names, field names, and default values
static char vyra_module_interfaces__msg__VBASEVolatileSet__FIELD_NAME__values[] = "values";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__msg__VBASEVolatileSet__FIELDS[] = {
  {
    {vyra_module_interfaces__msg__VBASEVolatileSet__FIELD_NAME__values, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__msg__VBASEVolatileSet__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__msg__VBASEVolatileSet__TYPE_NAME, 43, 43},
      {vyra_module_interfaces__msg__VBASEVolatileSet__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# VolatileSet.msg\n"
  "\n"
  "string[] values\n"
  "\n"
  "# This message is used to represent a volatile set parameter in the system.\n"
  "# The values field contains the list of string data that can change over time.\n"
  "# It is typically used for parameters that are expected to change frequently\n"
  "# and need to be communicated between different components or modules.\n"
  "# Example usage:\n"
  "# - values: [\"item1\", \"item2\", \"item3\"]";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__msg__VBASEVolatileSet__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__msg__VBASEVolatileSet__TYPE_NAME, 43, 43},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 395, 395},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__msg__VBASEVolatileSet__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__msg__VBASEVolatileSet__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
