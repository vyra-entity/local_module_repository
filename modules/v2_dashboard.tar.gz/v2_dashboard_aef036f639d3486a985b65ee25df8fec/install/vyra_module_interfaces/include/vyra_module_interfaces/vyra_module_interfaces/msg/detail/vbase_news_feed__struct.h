// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from vyra_module_interfaces:msg/VBASENewsFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_news_feed.h"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__STRUCT_H_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'message'
// Member 'module_name'
// Member 'module_id'
#include "rosidl_runtime_c/string.h"
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'uuid'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in msg/VBASENewsFeed in the package vyra_module_interfaces.
/**
  * NewsFeed.msg
 */
typedef struct vyra_module_interfaces__msg__VBASENewsFeed
{
  uint8_t level;
  rosidl_runtime_c__String message;
  builtin_interfaces__msg__Time timestamp;
  unique_identifier_msgs__msg__UUID uuid;
  rosidl_runtime_c__String module_name;
  rosidl_runtime_c__String module_id;
} vyra_module_interfaces__msg__VBASENewsFeed;

// Struct for a sequence of vyra_module_interfaces__msg__VBASENewsFeed.
typedef struct vyra_module_interfaces__msg__VBASENewsFeed__Sequence
{
  vyra_module_interfaces__msg__VBASENewsFeed * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} vyra_module_interfaces__msg__VBASENewsFeed__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_NEWS_FEED__STRUCT_H_
