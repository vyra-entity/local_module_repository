// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from vyra_module_interfaces:srv/VBASERequestAccess.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/vbase_request_access.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_REQUEST_ACCESS__STRUCT_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_REQUEST_ACCESS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'module_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Request __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Request __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct VBASERequestAccess_Request_
{
  using Type = VBASERequestAccess_Request_<ContainerAllocator>;

  explicit VBASERequestAccess_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : module_id(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->certificate = "";
      this->requested_level = 0;
      this->level_4_psw = "";
      this->level_5_passkey = "";
    }
  }

  explicit VBASERequestAccess_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : certificate(_alloc),
    module_id(_alloc, _init),
    level_4_psw(_alloc),
    level_5_passkey(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->certificate = "";
      this->requested_level = 0;
      this->level_4_psw = "";
      this->level_5_passkey = "";
    }
  }

  // field types and members
  using _certificate_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _certificate_type certificate;
  using _module_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _module_id_type module_id;
  using _requested_level_type =
    uint8_t;
  _requested_level_type requested_level;
  using _level_4_psw_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _level_4_psw_type level_4_psw;
  using _level_5_passkey_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _level_5_passkey_type level_5_passkey;

  // setters for named parameter idiom
  Type & set__certificate(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->certificate = _arg;
    return *this;
  }
  Type & set__module_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->module_id = _arg;
    return *this;
  }
  Type & set__requested_level(
    const uint8_t & _arg)
  {
    this->requested_level = _arg;
    return *this;
  }
  Type & set__level_4_psw(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->level_4_psw = _arg;
    return *this;
  }
  Type & set__level_5_passkey(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->level_5_passkey = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Request
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Request
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASERequestAccess_Request_ & other) const
  {
    if (this->certificate != other.certificate) {
      return false;
    }
    if (this->module_id != other.module_id) {
      return false;
    }
    if (this->requested_level != other.requested_level) {
      return false;
    }
    if (this->level_4_psw != other.level_4_psw) {
      return false;
    }
    if (this->level_5_passkey != other.level_5_passkey) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASERequestAccess_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASERequestAccess_Request_

// alias to use template instance with default allocator
using VBASERequestAccess_Request =
  vyra_module_interfaces::srv::VBASERequestAccess_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace vyra_module_interfaces


#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Response __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Response __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct VBASERequestAccess_Response_
{
  using Type = VBASERequestAccess_Response_<ContainerAllocator>;

  explicit VBASERequestAccess_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->access_status = 0;
      this->error_message = "";
    }
  }

  explicit VBASERequestAccess_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : error_message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->access_status = 0;
      this->error_message = "";
    }
  }

  // field types and members
  using _access_status_type =
    uint8_t;
  _access_status_type access_status;
  using _error_message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _error_message_type error_message;

  // setters for named parameter idiom
  Type & set__access_status(
    const uint8_t & _arg)
  {
    this->access_status = _arg;
    return *this;
  }
  Type & set__error_message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->error_message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Response
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Response
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASERequestAccess_Response_ & other) const
  {
    if (this->access_status != other.access_status) {
      return false;
    }
    if (this->error_message != other.error_message) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASERequestAccess_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASERequestAccess_Response_

// alias to use template instance with default allocator
using VBASERequestAccess_Response =
  vyra_module_interfaces::srv::VBASERequestAccess_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace vyra_module_interfaces


// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Event __attribute__((deprecated))
#else
# define DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Event __declspec(deprecated)
#endif

namespace vyra_module_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct VBASERequestAccess_Event_
{
  using Type = VBASERequestAccess_Event_<ContainerAllocator>;

  explicit VBASERequestAccess_Event_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit VBASERequestAccess_Event_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    service_msgs::msg::ServiceEventInfo_<ContainerAllocator>;
  _info_type info;
  using _request_type =
    rosidl_runtime_cpp::BoundedVector<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>>;
  _request_type request;
  using _response_type =
    rosidl_runtime_cpp::BoundedVector<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>>;
  _response_type response;

  // setters for named parameter idiom
  Type & set__info(
    const service_msgs::msg::ServiceEventInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }
  Type & set__request(
    const rosidl_runtime_cpp::BoundedVector<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<vyra_module_interfaces::srv::VBASERequestAccess_Request_<ContainerAllocator>>> & _arg)
  {
    this->request = _arg;
    return *this;
  }
  Type & set__response(
    const rosidl_runtime_cpp::BoundedVector<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<vyra_module_interfaces::srv::VBASERequestAccess_Response_<ContainerAllocator>>> & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> *;
  using ConstRawPtr =
    const vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Event
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__vyra_module_interfaces__srv__VBASERequestAccess_Event
    std::shared_ptr<vyra_module_interfaces::srv::VBASERequestAccess_Event_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VBASERequestAccess_Event_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    if (this->request != other.request) {
      return false;
    }
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const VBASERequestAccess_Event_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VBASERequestAccess_Event_

// alias to use template instance with default allocator
using VBASERequestAccess_Event =
  vyra_module_interfaces::srv::VBASERequestAccess_Event_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace vyra_module_interfaces

namespace vyra_module_interfaces
{

namespace srv
{

struct VBASERequestAccess
{
  using Request = vyra_module_interfaces::srv::VBASERequestAccess_Request;
  using Response = vyra_module_interfaces::srv::VBASERequestAccess_Response;
  using Event = vyra_module_interfaces::srv::VBASERequestAccess_Event;
};

}  // namespace srv

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_REQUEST_ACCESS__STRUCT_HPP_
