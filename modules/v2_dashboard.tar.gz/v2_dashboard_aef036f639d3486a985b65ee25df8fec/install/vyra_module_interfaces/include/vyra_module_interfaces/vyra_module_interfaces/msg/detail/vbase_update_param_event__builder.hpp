// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASEUpdateParamEvent.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_update_param_event.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_update_param_event__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASEUpdateParamEvent_timestamp
{
public:
  explicit Init_VBASEUpdateParamEvent_timestamp(::vyra_module_interfaces::msg::VBASEUpdateParamEvent & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent timestamp(::vyra_module_interfaces::msg::VBASEUpdateParamEvent::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent msg_;
};

class Init_VBASEUpdateParamEvent_id
{
public:
  explicit Init_VBASEUpdateParamEvent_id(::vyra_module_interfaces::msg::VBASEUpdateParamEvent & msg)
  : msg_(msg)
  {}
  Init_VBASEUpdateParamEvent_timestamp id(::vyra_module_interfaces::msg::VBASEUpdateParamEvent::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_VBASEUpdateParamEvent_timestamp(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent msg_;
};

class Init_VBASEUpdateParamEvent_changed_to
{
public:
  explicit Init_VBASEUpdateParamEvent_changed_to(::vyra_module_interfaces::msg::VBASEUpdateParamEvent & msg)
  : msg_(msg)
  {}
  Init_VBASEUpdateParamEvent_id changed_to(::vyra_module_interfaces::msg::VBASEUpdateParamEvent::_changed_to_type arg)
  {
    msg_.changed_to = std::move(arg);
    return Init_VBASEUpdateParamEvent_id(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent msg_;
};

class Init_VBASEUpdateParamEvent_changed_from
{
public:
  explicit Init_VBASEUpdateParamEvent_changed_from(::vyra_module_interfaces::msg::VBASEUpdateParamEvent & msg)
  : msg_(msg)
  {}
  Init_VBASEUpdateParamEvent_changed_to changed_from(::vyra_module_interfaces::msg::VBASEUpdateParamEvent::_changed_from_type arg)
  {
    msg_.changed_from = std::move(arg);
    return Init_VBASEUpdateParamEvent_changed_to(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent msg_;
};

class Init_VBASEUpdateParamEvent_param_key
{
public:
  Init_VBASEUpdateParamEvent_param_key()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEUpdateParamEvent_changed_from param_key(::vyra_module_interfaces::msg::VBASEUpdateParamEvent::_param_key_type arg)
  {
    msg_.param_key = std::move(arg);
    return Init_VBASEUpdateParamEvent_changed_from(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEUpdateParamEvent msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASEUpdateParamEvent>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASEUpdateParamEvent_param_key();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_UPDATE_PARAM_EVENT__BUILDER_HPP_
