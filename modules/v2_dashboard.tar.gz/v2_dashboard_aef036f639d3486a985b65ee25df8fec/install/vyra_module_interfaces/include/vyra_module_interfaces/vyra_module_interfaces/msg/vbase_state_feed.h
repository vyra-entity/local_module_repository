// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:msg/VBASEStateFeed.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_STATE_FEED_H_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_STATE_FEED_H_

#include "vyra_module_interfaces/msg/detail/vbase_state_feed__struct.h"
#include "vyra_module_interfaces/msg/detail/vbase_state_feed__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_state_feed__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_STATE_FEED_H_
