// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:msg/VBASELoggerStream.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_LOGGER_STREAM_H_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_LOGGER_STREAM_H_

#include "vyra_module_interfaces/msg/detail/vbase_logger_stream__struct.h"
#include "vyra_module_interfaces/msg/detail/vbase_logger_stream__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_logger_stream__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_LOGGER_STREAM_H_
