// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__SRV__VBASE_REQUEST_ACCESS_HPP_
#define VYRA_MODULE_INTERFACES__SRV__VBASE_REQUEST_ACCESS_HPP_

#include "vyra_module_interfaces/srv/detail/vbase_request_access__struct.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_request_access__builder.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_request_access__traits.hpp"
#include "vyra_module_interfaces/srv/detail/vbase_request_access__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__SRV__VBASE_REQUEST_ACCESS_HPP_
