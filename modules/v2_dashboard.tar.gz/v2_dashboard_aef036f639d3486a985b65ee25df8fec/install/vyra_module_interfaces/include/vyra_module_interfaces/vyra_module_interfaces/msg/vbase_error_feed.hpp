// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_ERROR_FEED_HPP_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_ERROR_FEED_HPP_

#include "vyra_module_interfaces/msg/detail/vbase_error_feed__struct.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_error_feed__builder.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_error_feed__traits.hpp"
#include "vyra_module_interfaces/msg/detail/vbase_error_feed__type_support.hpp"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_ERROR_FEED_HPP_
