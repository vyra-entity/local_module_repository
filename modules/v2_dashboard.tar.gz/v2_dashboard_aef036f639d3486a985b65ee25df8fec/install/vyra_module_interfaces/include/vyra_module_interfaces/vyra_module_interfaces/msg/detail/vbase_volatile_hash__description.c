// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:msg/VBASEVolatileHash.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/msg/detail/vbase_volatile_hash__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__msg__VBASEVolatileHash__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xcd, 0xe9, 0x02, 0xdf, 0x77, 0x04, 0x71, 0xe8,
      0x19, 0x95, 0xd0, 0x42, 0x1d, 0x86, 0x92, 0x3f,
      0x39, 0xde, 0xe9, 0x94, 0x1a, 0xc8, 0x3d, 0xef,
      0x7b, 0x1c, 0x4e, 0x2e, 0xe7, 0x27, 0xa9, 0x7b,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "vyra_module_interfaces/msg/detail/vbase_key_value__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH = {1, {
    0xf1, 0xb3, 0x1b, 0x9a, 0x16, 0x28, 0x74, 0xc8,
    0x2b, 0xb1, 0x77, 0xce, 0xbe, 0x87, 0x61, 0x15,
    0x89, 0xa3, 0x02, 0x60, 0x27, 0x37, 0xcb, 0x52,
    0x42, 0xaf, 0x11, 0x21, 0x8a, 0x1b, 0x27, 0x87,
  }};
#endif

static char vyra_module_interfaces__msg__VBASEVolatileHash__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEVolatileHash";
static char vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEKeyValue";

// Define type names, field names, and default values
static char vyra_module_interfaces__msg__VBASEVolatileHash__FIELD_NAME__entries[] = "entries";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__msg__VBASEVolatileHash__FIELDS[] = {
  {
    {vyra_module_interfaces__msg__VBASEVolatileHash__FIELD_NAME__entries, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription vyra_module_interfaces__msg__VBASEVolatileHash__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {vyra_module_interfaces__msg__VBASEKeyValue__TYPE_NAME, 40, 40},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__msg__VBASEVolatileHash__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__msg__VBASEVolatileHash__TYPE_NAME, 44, 44},
      {vyra_module_interfaces__msg__VBASEVolatileHash__FIELDS, 1, 1},
    },
    {vyra_module_interfaces__msg__VBASEVolatileHash__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&vyra_module_interfaces__msg__VBASEKeyValue__EXPECTED_HASH, vyra_module_interfaces__msg__VBASEKeyValue__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = vyra_module_interfaces__msg__VBASEKeyValue__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# VolatileHash.msg\n"
  "\n"
  "VBASEKeyValue[] entries\n"
  "\n"
  "# This message is used to represent a volatile hash parameter in the system.\n"
  "# The entries field contains the key-value pairs that can change over time.\n"
  "# It is typically used for parameters that are expected to change frequently\n"
  "# and need to be communicated between different components or modules.\n"
  "# Example usage:\n"
  "# - entries: [{key: \"field1\", value: \"value1\"}, {key: \"field2\", value: \"value2\"}]";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__msg__VBASEVolatileHash__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__msg__VBASEVolatileHash__TYPE_NAME, 44, 44},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 444, 444},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__msg__VBASEVolatileHash__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__msg__VBASEVolatileHash__get_individual_type_description_source(NULL),
    sources[1] = *vyra_module_interfaces__msg__VBASEKeyValue__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
