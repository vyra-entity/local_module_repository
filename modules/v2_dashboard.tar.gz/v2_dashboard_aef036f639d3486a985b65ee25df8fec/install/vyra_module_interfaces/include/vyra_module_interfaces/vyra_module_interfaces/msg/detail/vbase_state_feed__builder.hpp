// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:msg/VBASEStateFeed.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/msg/vbase_state_feed.hpp"


#ifndef VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/msg/detail/vbase_state_feed__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace msg
{

namespace builder
{

class Init_VBASEStateFeed_timestamp
{
public:
  explicit Init_VBASEStateFeed_timestamp(::vyra_module_interfaces::msg::VBASEStateFeed & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::msg::VBASEStateFeed timestamp(::vyra_module_interfaces::msg::VBASEStateFeed::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

class Init_VBASEStateFeed_module_name
{
public:
  explicit Init_VBASEStateFeed_module_name(::vyra_module_interfaces::msg::VBASEStateFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEStateFeed_timestamp module_name(::vyra_module_interfaces::msg::VBASEStateFeed::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_VBASEStateFeed_timestamp(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

class Init_VBASEStateFeed_module_id
{
public:
  explicit Init_VBASEStateFeed_module_id(::vyra_module_interfaces::msg::VBASEStateFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEStateFeed_module_name module_id(::vyra_module_interfaces::msg::VBASEStateFeed::_module_id_type arg)
  {
    msg_.module_id = std::move(arg);
    return Init_VBASEStateFeed_module_name(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

class Init_VBASEStateFeed_trigger
{
public:
  explicit Init_VBASEStateFeed_trigger(::vyra_module_interfaces::msg::VBASEStateFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEStateFeed_module_id trigger(::vyra_module_interfaces::msg::VBASEStateFeed::_trigger_type arg)
  {
    msg_.trigger = std::move(arg);
    return Init_VBASEStateFeed_module_id(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

class Init_VBASEStateFeed_current
{
public:
  explicit Init_VBASEStateFeed_current(::vyra_module_interfaces::msg::VBASEStateFeed & msg)
  : msg_(msg)
  {}
  Init_VBASEStateFeed_trigger current(::vyra_module_interfaces::msg::VBASEStateFeed::_current_type arg)
  {
    msg_.current = std::move(arg);
    return Init_VBASEStateFeed_trigger(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

class Init_VBASEStateFeed_previous
{
public:
  Init_VBASEStateFeed_previous()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEStateFeed_current previous(::vyra_module_interfaces::msg::VBASEStateFeed::_previous_type arg)
  {
    msg_.previous = std::move(arg);
    return Init_VBASEStateFeed_current(msg_);
  }

private:
  ::vyra_module_interfaces::msg::VBASEStateFeed msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::msg::VBASEStateFeed>()
{
  return vyra_module_interfaces::msg::builder::Init_VBASEStateFeed_previous();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__MSG__DETAIL__VBASE_STATE_FEED__BUILDER_HPP_
