// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from vyra_module_interfaces:msg/VBASEVolatileList.idl
// generated code does not contain a copyright notice

#include "vyra_module_interfaces/msg/detail/vbase_volatile_list__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_vyra_module_interfaces
const rosidl_type_hash_t *
vyra_module_interfaces__msg__VBASEVolatileList__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x05, 0xe5, 0xa9, 0x2d, 0x4c, 0xda, 0x24, 0x8d,
      0xc1, 0xc6, 0xaf, 0xf0, 0xff, 0xd4, 0x99, 0x00,
      0x7b, 0xab, 0xaa, 0x43, 0xb4, 0xa4, 0x3e, 0xf9,
      0xc6, 0xdd, 0x9b, 0x00, 0x80, 0xfe, 0x7e, 0xf9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char vyra_module_interfaces__msg__VBASEVolatileList__TYPE_NAME[] = "vyra_module_interfaces/msg/VBASEVolatileList";

// Define type names, field names, and default values
static char vyra_module_interfaces__msg__VBASEVolatileList__FIELD_NAME__values[] = "values";

static rosidl_runtime_c__type_description__Field vyra_module_interfaces__msg__VBASEVolatileList__FIELDS[] = {
  {
    {vyra_module_interfaces__msg__VBASEVolatileList__FIELD_NAME__values, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
vyra_module_interfaces__msg__VBASEVolatileList__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {vyra_module_interfaces__msg__VBASEVolatileList__TYPE_NAME, 44, 44},
      {vyra_module_interfaces__msg__VBASEVolatileList__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# VolatileList.msg\n"
  "\n"
  "string[] values\n"
  "\n"
  "# This message is used to represent a volatile list parameter in the system.\n"
  "# The values field contains the list of string data that can change over time.\n"
  "# It is typically used for parameters that are expected to change frequently\n"
  "# and need to be communicated between different components or modules.\n"
  "# Example usage:\n"
  "# - values: [\"item1\", \"item2\", \"item3\"]";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
vyra_module_interfaces__msg__VBASEVolatileList__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {vyra_module_interfaces__msg__VBASEVolatileList__TYPE_NAME, 44, 44},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 397, 397},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
vyra_module_interfaces__msg__VBASEVolatileList__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *vyra_module_interfaces__msg__VBASEVolatileList__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
