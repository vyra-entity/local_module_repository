// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:msg/VBASEVolatileList.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_LIST_H_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_LIST_H_

#include "vyra_module_interfaces/msg/detail/vbase_volatile_list__struct.h"
#include "vyra_module_interfaces/msg/detail/vbase_volatile_list__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_volatile_list__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_VOLATILE_LIST_H_
