# v2_dashboard - VYRA Dashboard mit Vue.js & Nginx

Template framework for building new python vyra modules with automatic SSL certificate management

## 🌐 Frontend-Architektur

Das v2_dashboard nutzt **Nginx als Frontend-Server** für optimale Performance:

### Modi:
- **Development**: Vue.js Dev Server (Hot-Reload)
- **Production**: Nginx Static Files (High-Performance)

### 🔐 Automatische SSL-Verwaltung:
- **Auto-Zertifikatserstellung** beim Container-Start
- **Ablaufprüfung** und automatische Erneuerung
- **Sichere Speicherung** in `/workspace/storage/certificates/`

### Schnellstart:
```bash
# Development-Modus
export VYRA_DEV_MODE=true
export ENABLE_BACKEND_WEBSERVER=true
docker-compose up v2_dashboard

# Production-Modus (Standard)
export VYRA_DEV_MODE=false
export ENABLE_FRONTEND_WEBSERVER=true
export ENABLE_BACKEND_WEBSERVER=true
docker-compose up v2_dashboard

# Nur Backend (API-Only)
export ENABLE_FRONTEND_WEBSERVER=false
export ENABLE_BACKEND_WEBSERVER=true
docker-compose up v2_dashboard
```

### URLs:
- **Frontend**: http://localhost:3000
- **Backend API**: https://localhost:8443

### Dokumentation:
- **Nginx Integration**: [docs/NGINX_INTEGRATION.md](docs/NGINX_INTEGRATION.md)
- **Environment Variables**: [docs/ENVIRONMENT_VARIABLES.md](docs/ENVIRONMENT_VARIABLES.md)
