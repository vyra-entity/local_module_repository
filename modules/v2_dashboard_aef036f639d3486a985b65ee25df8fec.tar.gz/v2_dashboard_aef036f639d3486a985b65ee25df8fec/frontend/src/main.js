import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { createPinia } from 'pinia'
import App from './App.vue'

// Global Styles
import './style.css'
import 'primeflex/primeflex.css'  // PrimeFlex Grid System

// PrimeVue Setup
import PrimeVue from 'primevue/config'
import Aura from '@primevue/themes/aura'
import ToastService from 'primevue/toastservice'
import ConfirmationService from 'primevue/confirmationservice'
import 'primeicons/primeicons.css'

// Import Views
import Home from './views/Home.vue'
import Modules from './views/Modules.vue'
import Monitoring from './views/Monitoring.vue'
import PrimeVueDemo from './components/PrimeVueDemo.vue'

// Router Setup
const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/modules', name: 'Modules', component: Modules },
  { path: '/monitoring', name: 'Monitoring', component: Monitoring },
  { path: '/primevue-demo', name: 'PrimeVueDemo', component: PrimeVueDemo }
]

const router = createRouter({
  history: createWebHistory('/v2_dashboard/'), // 🆕 Base path für Gateway-Routing
  routes
})

// Pinia Store
const pinia = createPinia()

// App Setup
const app = createApp(App)

// PrimeVue Configuration
app.use(PrimeVue, {
  theme: {
    preset: Aura,
    options: {
      darkModeSelector: false,
      cssLayer: false
    }
  }
})

app.use(ToastService)
app.use(ConfirmationService)
app.use(router)
app.use(pinia)
app.mount('#app')

// Global error handling
app.config.errorHandler = (err, vm, info) => {
  console.error('Vue error:', err, info)
}
