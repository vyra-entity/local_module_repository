<template>
  <div class="modules-view">
    <Card>
      <template #title>
        <div class="flex align-items-center justify-content-between">
          <span><i class="pi pi-box"></i> Modulverwaltung</span>
          <Button label="Neues Modul" icon="pi pi-plus" @click="showAddDialog = true" />
        </div>
      </template>
      <template #content>
        <!-- Filter/Search Bar -->
        <div class="flex gap-3 mb-4">
          <span class="p-input-icon-left flex-1">
            <i class="pi pi-search" />
            <InputText v-model="searchQuery" placeholder="Module durchsuchen..." class="w-full" />
          </span>
          <Dropdown v-model="statusFilter" :options="statusOptions" optionLabel="label" placeholder="Status filtern" class="w-12rem" />
        </div>

        <!-- Modules DataTable -->
        <DataTable 
          :value="filteredModules" 
          :paginator="true" 
          :rows="10" 
          :rowsPerPageOptions="[5, 10, 20]"
          sortField="name" 
          :sortOrder="1"
          stripedRows
          class="p-datatable-sm"
        >
          <Column field="name" header="Modulname" sortable>
            <template #body="{ data }">
              <div class="flex align-items-center gap-2">
                <i class="pi pi-box text-primary"></i>
                <span class="font-semibold">{{ data.name }}</span>
              </div>
            </template>
          </Column>

          <Column field="version" header="Version" sortable>
            <template #body="{ data }">
              <Tag :value="data.version" severity="info" />
            </template>
          </Column>

          <Column field="status" header="Status" sortable>
            <template #body="{ data }">
              <Tag 
                :value="data.status" 
                :severity="getStatusSeverity(data.status)" 
                :icon="getStatusIcon(data.status)"
              />
            </template>
          </Column>

          <Column field="port" header="Port" sortable />

          <Column field="memory" header="Memory" sortable>
            <template #body="{ data }">
              <ProgressBar :value="data.memory" :showValue="true" style="height: 1.5rem" />
            </template>
          </Column>

          <Column field="uptime" header="Uptime" sortable />

          <Column header="Aktionen" style="width: 12rem">
            <template #body="{ data }">
              <div class="flex gap-2">
                <Button 
                  :icon="data.status === 'running' ? 'pi pi-pause' : 'pi pi-play'" 
                  :severity="data.status === 'running' ? 'warning' : 'success'" 
                  size="small"
                  @click="toggleModule(data)"
                  v-tooltip.top="data.status === 'running' ? 'Stoppen' : 'Starten'"
                />
                <Button 
                  icon="pi pi-refresh" 
                  severity="info" 
                  size="small"
                  @click="restartModule(data)"
                  v-tooltip.top="'Neustart'"
                />
                <Button 
                  icon="pi pi-trash" 
                  severity="danger" 
                  size="small"
                  @click="confirmDelete(data)"
                  v-tooltip.top="'Löschen'"
                />
              </div>
            </template>
          </Column>
        </DataTable>
      </template>
    </Card>

    <!-- Add Module Dialog -->
    <Dialog v-model:visible="showAddDialog" header="Neues Modul hinzufügen" :modal="true" :style="{ width: '40vw' }">
      <div class="flex flex-column gap-3">
        <div class="field">
          <label for="moduleName" class="font-semibold">Modulname</label>
          <InputText id="moduleName" v-model="newModule.name" class="w-full" />
        </div>
        <div class="field">
          <label for="modulePort" class="font-semibold">Port</label>
          <InputNumber id="modulePort" v-model="newModule.port" class="w-full" />
        </div>
        <div class="field">
          <label for="moduleVersion" class="font-semibold">Version</label>
          <InputText id="moduleVersion" v-model="newModule.version" class="w-full" />
        </div>
      </div>
      <template #footer>
        <Button label="Abbrechen" icon="pi pi-times" text @click="showAddDialog = false" />
        <Button label="Hinzufügen" icon="pi pi-check" @click="addModule" />
      </template>
    </Dialog>

    <!-- Delete Confirmation -->
    <ConfirmDialog></ConfirmDialog>
    <Toast />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useConfirm } from 'primevue/useconfirm'
import { useToast } from 'primevue/usetoast'
import Card from 'primevue/card'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import InputNumber from 'primevue/inputnumber'
import Dropdown from 'primevue/dropdown'
import Tag from 'primevue/tag'
import ProgressBar from 'primevue/progressbar'
import Dialog from 'primevue/dialog'
import ConfirmDialog from 'primevue/confirmdialog'
import Toast from 'primevue/toast'

const confirm = useConfirm()
const toast = useToast()

const searchQuery = ref('')
const statusFilter = ref(null)
const showAddDialog = ref(false)

const statusOptions = [
  { label: 'Alle', value: null },
  { label: 'Aktiv', value: 'running' },
  { label: 'Gestoppt', value: 'stopped' },
  { label: 'Fehler', value: 'error' }
]

const modules = ref([
  { id: 1, name: 'v2_dashboard', version: '2.0.0', status: 'running', port: 8000, memory: 45, uptime: '2h 15m' },
  { id: 2, name: 'v2_modulemanager', version: '2.0.0', status: 'running', port: 8001, memory: 32, uptime: '2h 15m' },
  { id: 3, name: 'vision_module', version: '1.5.2', status: 'stopped', port: 8002, memory: 0, uptime: '-' },
  { id: 4, name: 'robotics_controller', version: '3.1.0', status: 'running', port: 8003, memory: 68, uptime: '1h 30m' },
  { id: 5, name: 'data_logger', version: '1.2.1', status: 'error', port: 8004, memory: 15, uptime: '-' }
])

const newModule = ref({
  name: '',
  port: null,
  version: '1.0.0'
})

const filteredModules = computed(() => {
  let result = modules.value

  // Filter by search query
  if (searchQuery.value) {
    result = result.filter(m => 
      m.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
      m.version.includes(searchQuery.value)
    )
  }

  // Filter by status
  if (statusFilter.value?.value) {
    result = result.filter(m => m.status === statusFilter.value.value)
  }

  return result
})

const getStatusSeverity = (status) => {
  switch (status) {
    case 'running': return 'success'
    case 'stopped': return 'warning'
    case 'error': return 'danger'
    default: return 'info'
  }
}

const getStatusIcon = (status) => {
  switch (status) {
    case 'running': return 'pi pi-check-circle'
    case 'stopped': return 'pi pi-pause-circle'
    case 'error': return 'pi pi-exclamation-circle'
    default: return 'pi pi-info-circle'
  }
}

const toggleModule = (module) => {
  if (module.status === 'running') {
    module.status = 'stopped'
    module.memory = 0
    module.uptime = '-'
    toast.add({ severity: 'info', summary: 'Gestoppt', detail: `${module.name} wurde gestoppt`, life: 3000 })
  } else {
    module.status = 'running'
    module.memory = Math.floor(Math.random() * 50) + 20
    module.uptime = '0m'
    toast.add({ severity: 'success', summary: 'Gestartet', detail: `${module.name} wurde gestartet`, life: 3000 })
  }
}

const restartModule = (module) => {
  toast.add({ severity: 'info', summary: 'Neustart', detail: `${module.name} wird neu gestartet...`, life: 3000 })
  module.uptime = '0m'
}

const confirmDelete = (module) => {
  confirm.require({
    message: `Möchten Sie ${module.name} wirklich löschen?`,
    header: 'Löschen bestätigen',
    icon: 'pi pi-exclamation-triangle',
    acceptLabel: 'Ja, löschen',
    rejectLabel: 'Abbrechen',
    accept: () => {
      modules.value = modules.value.filter(m => m.id !== module.id)
      toast.add({ severity: 'success', summary: 'Gelöscht', detail: `${module.name} wurde gelöscht`, life: 3000 })
    }
  })
}

const addModule = () => {
  if (newModule.value.name && newModule.value.port) {
    modules.value.push({
      id: modules.value.length + 1,
      name: newModule.value.name,
      version: newModule.value.version,
      status: 'stopped',
      port: newModule.value.port,
      memory: 0,
      uptime: '-'
    })
    toast.add({ severity: 'success', summary: 'Hinzugefügt', detail: `${newModule.value.name} wurde hinzugefügt`, life: 3000 })
    showAddDialog.value = false
    newModule.value = { name: '', port: null, version: '1.0.0' }
  }
}
</script>

<style scoped>
.modules-view {
  animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
