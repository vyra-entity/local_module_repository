<template>
  <div class="home-view">
    <!-- Hero Section -->
    <Card class="hero-card">
      <template #content>
        <div class="text-center py-5">
          <i class="pi pi-bolt" style="font-size: 4rem; color: white"></i>
          <h1 class="text-5xl font-bold mt-3 mb-2">VYRA Dashboard</h1>
          <p class="text-xl text-100">Zentrale Steuerung für Ihre Automatisierungslösungen</p>
        </div>
      </template>
    </Card>

    <!-- Stats Grid -->
    <div class="stats-container">
      <div class="grid mt-4">
        <div class="col-12 md:col-6 lg:col-3">
        <Card>
          <template #content>
            <div class="flex align-items-center justify-content-between">
              <div>
                <div class="text-500 font-medium mb-2">Aktive Module</div>
                <div class="text-3xl font-bold">{{ stats.modules }}</div>
              </div>
              <div class="flex align-items-center justify-content-center bg-blue-100 border-round" style="width:3rem;height:3rem">
                <i class="pi pi-box text-blue-500 text-xl"></i>
              </div>
            </div>
          </template>
        </Card>
      </div>

      <div class="col-12 md:col-6 lg:col-3">
        <Card>
          <template #content>
            <div class="flex align-items-center justify-content-between">
              <div>
                <div class="text-500 font-medium mb-2">System Uptime</div>
                <div class="text-3xl font-bold">{{ stats.uptime }}</div>
              </div>
              <div class="flex align-items-center justify-content-center bg-green-100 border-round" style="width:3rem;height:3rem">
                <i class="pi pi-bolt text-green-500 text-xl"></i>
              </div>
            </div>
          </template>
        </Card>
      </div>

      <div class="col-12 md:col-6 lg:col-3">
        <Card>
          <template #content>
            <div class="flex align-items-center justify-content-between">
              <div>
                <div class="text-500 font-medium mb-2">Laufende Services</div>
                <div class="text-3xl font-bold">{{ stats.services }}</div>
              </div>
              <div class="flex align-items-center justify-content-center bg-purple-100 border-round" style="width:3rem;height:3rem">
                <i class="pi pi-cog text-purple-500 text-xl"></i>
              </div>
            </div>
          </template>
        </Card>
      </div>

      <div class="col-12 md:col-6 lg:col-3">
        <Card>
          <template #content>
            <div class="flex align-items-center justify-content-between">
              <div>
                <div class="text-500 font-medium mb-2">Memory Usage</div>
                <div class="text-3xl font-bold">{{ stats.memory }}%</div>
              </div>
              <div class="flex align-items-center justify-content-center bg-orange-100 border-round" style="width:3rem;height:3rem">
                <i class="pi pi-chart-bar text-orange-500 text-xl"></i>
              </div>
            </div>
          </template>
        </Card>
      </div>
    </div>
    </div>

    <!-- Quick Actions -->
    <Card class="mt-4">
      <template #title>
        <i class="pi pi-bolt"></i> Schnellzugriff
      </template>
      <template #content>
        <div class="grid">
          <div class="col-12 md:col-4">
            <Card class="quick-action-card" @click="$router.push('/modules')">
              <template #content>
                <div class="text-center">
                  <i class="pi pi-box" style="font-size: 3rem; color: var(--primary-color)"></i>
                  <h3 class="mt-3 mb-2">Module verwalten</h3>
                  <p class="text-600">Module starten, stoppen und konfigurieren</p>
                </div>
              </template>
            </Card>
          </div>

          <div class="col-12 md:col-4">
            <Card class="quick-action-card" @click="$router.push('/monitoring')">
              <template #content>
                <div class="text-center">
                  <i class="pi pi-chart-line" style="font-size: 3rem; color: var(--primary-color)"></i>
                  <h3 class="mt-3 mb-2">System-Monitoring</h3>
                  <p class="text-600">Performance und Logs überwachen</p>
                </div>
              </template>
            </Card>
          </div>

          <div class="col-12 md:col-4">
            <Card class="quick-action-card" @click="showSystemInfo = true">
              <template #content>
                <div class="text-center">
                  <i class="pi pi-info-circle" style="font-size: 3rem; color: var(--primary-color)"></i>
                  <h3 class="mt-3 mb-2">System-Info</h3>
                  <p class="text-600">Detaillierte Systeminformationen</p>
                </div>
              </template>
            </Card>
          </div>
        </div>
      </template>
    </Card>

    <!-- System Info Dialog -->
    <Dialog v-model:visible="showSystemInfo" header="System-Informationen" :modal="true" :style="{ width: '50vw' }">
      <div class="flex flex-column gap-3">
        <div class="flex justify-content-between align-items-center p-3 surface-100 border-round">
          <span class="font-semibold">VYRA Version:</span>
          <Tag :value="systemInfo.version" severity="info" />
        </div>
        <div class="flex justify-content-between align-items-center p-3 surface-100 border-round">
          <span class="font-semibold">Backend Status:</span>
          <Tag :value="systemInfo.backendStatus" :severity="systemInfo.backendStatus === 'running' ? 'success' : 'danger'" />
        </div>
        <div class="flex justify-content-between align-items-center p-3 surface-100 border-round">
          <span class="font-semibold">Frontend:</span>
          <span>Vue.js {{ systemInfo.vueVersion }}</span>
        </div>
        <div class="flex justify-content-between align-items-center p-3 surface-100 border-round">
          <span class="font-semibold">Letzter Start:</span>
          <span>{{ systemInfo.lastStart }}</span>
        </div>
      </div>
      <template #footer>
        <Button label="Schließen" icon="pi pi-times" @click="showSystemInfo = false" />
      </template>
    </Dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import Card from 'primevue/card'
import Dialog from 'primevue/dialog'
import Button from 'primevue/button'
import Tag from 'primevue/tag'

const showSystemInfo = ref(false)

const stats = ref({
  modules: 3,
  uptime: '99.9%',
  services: 12,
  memory: 45
})

const systemInfo = ref({
  version: '2.0.0',
  backendStatus: 'running',
  vueVersion: '3.4.0',
  lastStart: new Date().toLocaleString('de-DE')
})

onMounted(() => {
  console.log('Home View geladen')
})
</script>

<style scoped>
.home-view {
  animation: fadeIn 0.3s ease-in;
  overflow: hidden;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Hero Card with explicit white colors */
.hero-card {
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%) !important;
}

.hero-card :deep(.p-card-content) {
  color: white !important;
}

.hero-card h1 {
  color: white !important;
}

.hero-card p {
  color: white !important;
}

/* Stats Container - Critical for Grid Layout */
.stats-container {
  width: 100%;
  overflow: hidden;
}

.stats-container :deep(.grid) {
  margin-left: 0 !important;
  margin-right: 0 !important;
}

.stats-container :deep([class*='col-']) {
  padding: 0.5rem !important;
}

.stats-container :deep(.p-card) {
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  height: 100%;
}

.quick-action-card {
  cursor: pointer;
  transition: all 0.3s ease;
  height: 100%;
}

.quick-action-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
}
</style>
