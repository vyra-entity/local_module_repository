# Add database structures here to be loaded at startup

