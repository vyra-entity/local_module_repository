import asyncio
import datetime
import json
import os
from vyra_base.helper.logger import Logger
from vyra_base.core.entity import VyraEntity

from ..taskmanager import TaskManager

from vyra_base.com.datalayer.interface_factory import execute_vyra_callable

from vyra_module_interfaces.srv import VBASEGetInterfaceList # pyright: ignore[reportAttributeAccessIssue] 

def test_vyra_speaker(msg):
    Logger.info(f"Testing VyraSpeaker...: {msg}")
    return

async def main(entity: VyraEntity, task_manager: TaskManager) -> None:
    Logger.info("Starting VYRA Dashboard...")
    
    # Development und Production Server werden über Supervisord/Entrypoint verwaltet
    # Frontend: Vite Dev Server (VYRA_DEV_MODE=true) oder Nginx (VYRA_DEV_MODE=false)
    # Backend: Uvicorn ASGI Server (über Supervisord)
    development_mode = os.getenv("VYRA_DEV_MODE", "false").lower() == "true"
    
    if development_mode:
        Logger.info("🔧 Development-Modus aktiv")
        Logger.info("   🖥️ Frontend: http://localhost:3000 (Vite Dev Server via Entrypoint)")
        Logger.info("   🔧 Backend API: https://localhost:8443 (Uvicorn via Supervisord)")
    else:
        Logger.info("🌐 Production-Modus aktiv")
        Logger.info("   🌐 Frontend: http://localhost:3000 (Nginx via Supervisord)")
        Logger.info("   🔧 Backend API: https://localhost:8443 (Uvicorn via Supervisord)")
    
    # ROS2-Modul bleibt aktiv
    while True:
        await asyncio.sleep(10)

    # Beispiel für eine Vyra Callable Execution
    # Logger.debug("Testing VyraCallableExecutor...")
    # result = await execute_vyra_callable(
    #     VBASEGetInterfaceList,
    #     getattr(entity, "node"),
    #     {},
    #     ident_name="get_interface_list",
    #     timeout=10
    # )
    
    # for r in result.interface_list:
    #     Logger.info(f"Result from VBASEGetInterfaceList: {json.loads(r)}")
    
    # for r in result.interface_list:
    #     Logger.info(f"Result from VBASEGetInterfaceList: {json.loads(r)}")