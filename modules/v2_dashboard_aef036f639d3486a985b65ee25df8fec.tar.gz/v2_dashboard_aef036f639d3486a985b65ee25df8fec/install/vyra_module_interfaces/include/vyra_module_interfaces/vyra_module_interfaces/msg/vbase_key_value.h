// generated from rosidl_generator_c/resource/idl.h.em
// with input from vyra_module_interfaces:msg/VBASEKeyValue.idl
// generated code does not contain a copyright notice

#ifndef VYRA_MODULE_INTERFACES__MSG__VBASE_KEY_VALUE_H_
#define VYRA_MODULE_INTERFACES__MSG__VBASE_KEY_VALUE_H_

#include "vyra_module_interfaces/msg/detail/vbase_key_value__struct.h"
#include "vyra_module_interfaces/msg/detail/vbase_key_value__functions.h"
#include "vyra_module_interfaces/msg/detail/vbase_key_value__type_support.h"

#endif  // VYRA_MODULE_INTERFACES__MSG__VBASE_KEY_VALUE_H_
