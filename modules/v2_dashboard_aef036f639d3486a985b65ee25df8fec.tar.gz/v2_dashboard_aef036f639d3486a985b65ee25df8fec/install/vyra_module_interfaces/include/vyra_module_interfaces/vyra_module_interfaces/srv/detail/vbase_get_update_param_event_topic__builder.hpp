// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:srv/VBASEGetUpdateParamEventTopic.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/vbase_get_update_param_event_topic.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/srv/detail/vbase_get_update_param_event_topic__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Request>()
{
  return ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEGetUpdateParamEventTopic_Response_topic
{
public:
  Init_VBASEGetUpdateParamEventTopic_Response_topic()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Response topic(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Response::_topic_type arg)
  {
    msg_.topic = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Response>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEGetUpdateParamEventTopic_Response_topic();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEGetUpdateParamEventTopic_Event_response
{
public:
  explicit Init_VBASEGetUpdateParamEventTopic_Event_response(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event response(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event msg_;
};

class Init_VBASEGetUpdateParamEventTopic_Event_request
{
public:
  explicit Init_VBASEGetUpdateParamEventTopic_Event_request(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event & msg)
  : msg_(msg)
  {}
  Init_VBASEGetUpdateParamEventTopic_Event_response request(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_VBASEGetUpdateParamEventTopic_Event_response(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event msg_;
};

class Init_VBASEGetUpdateParamEventTopic_Event_info
{
public:
  Init_VBASEGetUpdateParamEventTopic_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEGetUpdateParamEventTopic_Event_request info(::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_VBASEGetUpdateParamEventTopic_Event_request(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEGetUpdateParamEventTopic_Event>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEGetUpdateParamEventTopic_Event_info();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_GET_UPDATE_PARAM_EVENT_TOPIC__BUILDER_HPP_
