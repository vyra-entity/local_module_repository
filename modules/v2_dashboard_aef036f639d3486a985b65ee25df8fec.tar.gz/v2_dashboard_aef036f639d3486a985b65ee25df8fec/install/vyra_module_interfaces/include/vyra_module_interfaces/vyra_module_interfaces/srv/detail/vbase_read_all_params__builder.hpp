// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from vyra_module_interfaces:srv/VBASEReadAllParams.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "vyra_module_interfaces/srv/vbase_read_all_params.hpp"


#ifndef VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_READ_ALL_PARAMS__BUILDER_HPP_
#define VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_READ_ALL_PARAMS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "vyra_module_interfaces/srv/detail/vbase_read_all_params__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace vyra_module_interfaces
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEReadAllParams_Request>()
{
  return ::vyra_module_interfaces::srv::VBASEReadAllParams_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEReadAllParams_Response_all_params_json
{
public:
  Init_VBASEReadAllParams_Response_all_params_json()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Response all_params_json(::vyra_module_interfaces::srv::VBASEReadAllParams_Response::_all_params_json_type arg)
  {
    msg_.all_params_json = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEReadAllParams_Response>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEReadAllParams_Response_all_params_json();
}

}  // namespace vyra_module_interfaces


namespace vyra_module_interfaces
{

namespace srv
{

namespace builder
{

class Init_VBASEReadAllParams_Event_response
{
public:
  explicit Init_VBASEReadAllParams_Event_response(::vyra_module_interfaces::srv::VBASEReadAllParams_Event & msg)
  : msg_(msg)
  {}
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Event response(::vyra_module_interfaces::srv::VBASEReadAllParams_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Event msg_;
};

class Init_VBASEReadAllParams_Event_request
{
public:
  explicit Init_VBASEReadAllParams_Event_request(::vyra_module_interfaces::srv::VBASEReadAllParams_Event & msg)
  : msg_(msg)
  {}
  Init_VBASEReadAllParams_Event_response request(::vyra_module_interfaces::srv::VBASEReadAllParams_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_VBASEReadAllParams_Event_response(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Event msg_;
};

class Init_VBASEReadAllParams_Event_info
{
public:
  Init_VBASEReadAllParams_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VBASEReadAllParams_Event_request info(::vyra_module_interfaces::srv::VBASEReadAllParams_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_VBASEReadAllParams_Event_request(msg_);
  }

private:
  ::vyra_module_interfaces::srv::VBASEReadAllParams_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::vyra_module_interfaces::srv::VBASEReadAllParams_Event>()
{
  return vyra_module_interfaces::srv::builder::Init_VBASEReadAllParams_Event_info();
}

}  // namespace vyra_module_interfaces

#endif  // VYRA_MODULE_INTERFACES__SRV__DETAIL__VBASE_READ_ALL_PARAMS__BUILDER_HPP_
